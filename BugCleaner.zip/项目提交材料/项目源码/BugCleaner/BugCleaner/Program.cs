﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ThinkGeo.BugChecker
{
    public static class Program
    {
        //计时
        private static TimeSpan startTime;
        private static TimeSpan endTime;
        private static bool IsFinishi = false;

        //便于全局检测时间
        private static Crawler crawler = new Crawler();
        private static Download download = new Download();
        private static Compile compile = new Compile();
        private static Upload upload = new Upload();
        private static AutoRun autoRun = new AutoRun();

        public static void Main(string[] args)
        {
            Init();

            startTime = new TimeSpan(DateTime.Now.Ticks);
            ReportUsedTime();

            //控制任务的顺序执行

            //开始运行
            Tools.WirteRedToConsole("Woking...");
            crawler.StartupCrawler();
            crawler.IsStart = true;
            Tools.WirteRedToConsole("crawler start");

            //crawler finish, download start
            while (true)
            {
                if (crawler.IsFinish)
                {
                    download.IsStart = true;
                    download.StartupDownload();
                    download.ReportInterval = 10000;
                    Tools.WirteRedToConsole("download start");
                    break;
                }
                Thread.Sleep(5000);
            }

            // download finish,  compile start
            while (true)
            {
                if (download.IsFinish)
                {
                    compile.IsStart = true;
                    compile.StartupCompile();
                    Tools.WirteRedToConsole("compile start");
                    break;
                }
                Thread.Sleep(20000);
            }

            // compile finish,  upload start
            while (true)
            {
                if (compile.IsFinish)
                {
                    upload.StartUpUpload();
                    Tools.WirteRedToConsole("upload start");
                    break;
                }
                Thread.Sleep(20000);
            }

            // upload finish
            while (true)
            {
                if (upload.IsFinish)
                {
                    Tools.WirteRedToConsole("upload finish");
                    Log.WirteLog("upload finish");

                    break;
                }
                Thread.Sleep(5000);
            }

            //停止计时
            IsFinishi = true;

            //等待用户选择是否进行自动测试
            while (true)
            {
                //等待用户选择
                Console.WriteLine();
                Console.WriteLine("Do you want to run all uploaded projects? y/n");
                string input = Console.ReadLine();
                if (input.Equals("n"))
                {
                    break;
                }
                if (input.Equals("y"))
                {
                    Tools.WirteRedToConsole("please don't operate the mouse and keyboard!!!");
                    autoRun.StartupAutoRun();
                    //重新计时
                    ReportUsedTime();
                    break;
                }
            }

            while (true)
            {
                if (autoRun.IsFinish)
                {
                    Console.WriteLine("All done,you can check the log.txt and close this window!!!");
                    IsFinishi = true;
                }
            }

        }

        public static void Init()
        {
            Console.Title = "BugChecker";
        }

        /// <summary>
        /// 进度报告
        /// </summary>
        public static void ReportUsedTime()
        {
            var report = new Task(() =>
            {
                while (true)
                {
                    if (IsFinishi)
                        break;

                    //用时:
                    endTime = new TimeSpan(DateTime.Now.Ticks);
                    TimeSpan timeInterval = startTime.Subtract(endTime).Duration();//时间差的绝对值
                    string usedTime = timeInterval.Hours.ToString() + "h:" + timeInterval.Minutes.ToString() + "m:" + timeInterval.Seconds.ToString() + "s";

                    //设置前景色，即字体颜色
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("Timer: " + usedTime);

                    //设置前景色，即字体颜色
                    Console.ForegroundColor = ConsoleColor.White;
                    Thread.Sleep(10000);

                    //爬虫阶段
                    if (crawler.IsStart == true && crawler.IsFinish == false)
                    {
                        Console.WriteLine("Crawler is working!!!");
                    }

                    //判断从程序启动到目前,下载阶段用时超过25分钟,则结束下载;
                    if (download.IsStart == true && download.IsFinish == false)
                    {
                        Log.WirteLog("Download used time" + Convert.ToInt32(timeInterval.Minutes.ToString()));
                        if (Convert.ToInt32(timeInterval.Minutes.ToString()) > 25)
                        {
                            download.IsFinish = true;
                        }
                    }
                }

            }, TaskCreationOptions.AttachedToParent);
            report.Start();
        }
    }
}
