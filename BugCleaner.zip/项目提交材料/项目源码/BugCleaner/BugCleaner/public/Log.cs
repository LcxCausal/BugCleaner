﻿using System;
using System.IO;
using System.Text;

namespace ThinkGeo.BugChecker
{
    public class Log
    {
        private static Object sycObj = new Object();

        /// <summary>
        /// 存入日志(自动增加当前时间)
        /// </summary>
        /// <param name="message">输出信息</param>
        public static void WirteLog(string message)
        {
            message = Environment.NewLine + DateTime.Now.ToString() + Environment.NewLine + message;
            string logFilePath = MyPath.Combine(Config.rootDir, R.LogFile);
            if (!File.Exists(logFilePath))
            {
                lock (sycObj)
                {
                    FileOperation.CreateFileAndDir(logFilePath);
                }
            }
            lock (sycObj)
            {
                File.AppendAllText(logFilePath, message, Encoding.UTF8);
            }

        }

    }
}
