﻿using System;
using System.Runtime.CompilerServices;

namespace ThinkGeo.BugChecker
{
    public class HandleException
    {
        private static object sycObj = new object();

        /// <summary>
        /// 记录
        /// 1. 异常发生时间
        /// 2. 简短异常信息
        /// 3. 异常堆栈信息
        /// </summary>
        /// <param name="shortMsg">系统错误提示信息</param>
        /// <param name="stackMsg">异常堆栈信息</param>
        /// <param name="line"></param>
        /// <param name="path"></param>
        /// <param name="name"></param>
        public static void WirteLog(string shortMsg,
            string stackMsg,
          [CallerLineNumber] int line = -1,
          [CallerFilePath] string path = null,
          [CallerMemberName] string name = null
         )
        {
            lock (sycObj)
            {
                string errorMsg = DateTime.Now.ToString();
                errorMsg += Environment.NewLine;

                errorMsg += "简短异常信息:" + shortMsg;
                errorMsg += Environment.NewLine;

                errorMsg += "异常堆栈信息:" + stackMsg;
                errorMsg += Environment.NewLine;

                errorMsg += (path == null) ? "No file path" : "调用方法所在文件" + path;
                errorMsg += Environment.NewLine;

                errorMsg += (name == null) ? "No member name" : "调用者名(方法或属性)" + name;
                errorMsg += Environment.NewLine;

                //设置前景色，即字体颜色
                Console.ForegroundColor = ConsoleColor.Red; 
                Console.Write(errorMsg);

                //将控制台的前景色和背景色设为默认值
                Console.ResetColor(); 

                Log.WirteLog(errorMsg);
            }
        }
    }
}
