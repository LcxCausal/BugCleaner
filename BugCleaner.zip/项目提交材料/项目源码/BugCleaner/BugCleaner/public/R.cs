﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThinkGeo.BugChecker
{
    /// <summary>
    /// 程序中用到的字符串资源
    /// </summary>
    public static class R
    {
        // 爬取结果文件相关
        public static readonly string Zip = "Zip";
        public static readonly string ChildsNumber = "ChildsNumber";
        public static readonly string ZipsNum = "ZipsNum";
        public static readonly string CategoryNumber = "CategoryNumber";

        // 规则文件相关
        public static readonly string RuleList = "RuleList";
        public static readonly string RuleNode = "RuleNode";
        public static readonly string Config = "Config";
        public static readonly string BaseUrl = "BaseUrl";
        public static readonly string Prefix = "Prefix";
        public static readonly string XPath = "xPath";
        public static readonly string RegularExpression = "regex";
        public static readonly string Depth = "depth";

        public static readonly string XpathSeparator = "//";//xpath路径分隔符
        public static readonly string Settings = "Settings";
        public static readonly string HintPath = "HintPath";
        public static readonly string BuildFailed = "Build FAILED";
        public static readonly string BuildSuccess = "Build succeeded";

        //文件后缀名
        public static readonly string ExtCsproj = "*.csproj";
        public static readonly string ExtVbproj = "*.vbproj";
        public static readonly string ExtSln = "*.sln";
        public static readonly string ExtDll = "*.dll";
        public static readonly string ExtZip = "*.zip";
        public static readonly string VsDevenvExeName = "devenv";
        public static readonly string JPG = ".jpg";
        public static readonly string ScreenShot = "ScreenShot";
        public static readonly string CrawlerResultRootNODE = "Categorys";
        public static readonly string categoryName = "categoryName";
        public static readonly string EnterKey = "{Enter}";
        public static readonly string CtrlF5Key = "^{F5}";//Ctrl+F5 组合键   
        public static readonly string ProductHeader = "ThinkGeoUpload";
        public static readonly string LogFile = "log.txt";
        public static readonly string DOT = ".";

        /// <summary>
        /// 文件路径分隔符(\\)
        /// </summary>
        /// <returns></returns>
        public static char Sep()
        {
            return Path.DirectorySeparatorChar;
        }

    }
}
