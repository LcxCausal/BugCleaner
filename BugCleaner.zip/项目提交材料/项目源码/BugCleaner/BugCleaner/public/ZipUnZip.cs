﻿using ICSharpCode.SharpZipLib.Checksums;
using ICSharpCode.SharpZipLib.Zip;
using System;
using System.IO;

namespace ThinkGeo.BugChecker
{
    public class ZipUnZip
    {
        //解压：zip.UnZip(@"F:\a.zip", "");//将F:\a.zip解压到当前文件夹
        // zip.UnZip(@"F:\a.zip", "D:\");//将F:\a.zip解压到指定文件夹
        //100MB写一次 
        public int avg = 1024 * 1024 * 100;

        /// <summary>   
        /// 功能：解压zip格式的文件。   
        /// </summary>   
        /// <param name="zipFilePath">压缩文件路径，全路径格式</param>   
        /// <param name="unZipDir">解压文件存放路径,全路径格式，为空时默认与压缩文件同一级目录下，跟压缩文件同名的文件夹</param>   
        /// <returns>解压是否成功</returns>   
        public static bool UnZip(string zipFilePath, string unZipDir)
        {
            if (zipFilePath == string.Empty)
                throw new ArgumentNullException("zipFilePath！");

            //解压文件夹为空时默认与压缩文件同一级目录下，跟压缩文件同名的文件夹  
            if (unZipDir == string.Empty)
                unZipDir = zipFilePath.Replace(Path.GetFileName(zipFilePath), "");
            if (!unZipDir.EndsWith("//"))
                unZipDir += "//";

            if (!Directory.Exists(unZipDir))
                Directory.CreateDirectory(unZipDir);

            try
            {
                using (ZipInputStream s = new ZipInputStream(File.OpenRead(zipFilePath)))
                {
                    ZipEntry theEntry;
                    while ((theEntry = s.GetNextEntry()) != null)
                    {
                        string directoryName = Path.GetDirectoryName(theEntry.Name);
                        string fileName = Path.GetFileName(theEntry.Name);
                        if (directoryName.Length > 0)
                            Directory.CreateDirectory(unZipDir + directoryName);
                        if (!directoryName.EndsWith("//"))
                            directoryName += "//";
                        if (fileName != String.Empty)
                        {
                            using (FileStream streamWriter = File.Create(unZipDir + theEntry.Name))
                            {
                                int size = 2048;
                                byte[] data = new byte[2048];
                                while (true)
                                {
                                    size = s.Read(data, 0, data.Length);
                                    if (size > 0)
                                        streamWriter.Write(data, 0, size);
                                    else
                                        break;
                                }
                            }
                        }
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                string shortMsg = e.Message;
                string stackMsg = e.StackTrace;
                HandleException.WirteLog(shortMsg, stackMsg);
            }
            return true;
        }

        /// <summary>
        /// 递归压缩文件夹方法
        /// </summary>
        /// <param name="folderToZip">要被压缩的文件夹</param>
        /// <param name="zipOutputStream">zip输出流</param>
        /// <param name="parentFolderName">父目录</param>
        private bool ZipFileDictory(string folderToZip, ZipOutputStream zipOutputStream, string parentFolderName)
        {
            bool result = true;
            string[] folders, files;
            ZipEntry entry = null;
            FileStream fs = null;
            Crc32 crc = new Crc32();
            try
            {
                //创建当前文件夹
                //加上 “/” 才会当成是文件夹创建
                entry = new ZipEntry(Path.Combine(parentFolderName, Path.GetFileName(folderToZip) + "/"));
                zipOutputStream.PutNextEntry(entry);
                zipOutputStream.Flush();

                //先压缩文件，再递归压缩文件夹 
                files = Directory.GetFiles(folderToZip);
                foreach (string file in files)
                {
                    //打开压缩文件
                    fs = File.OpenRead(file);
                    byte[] buffer = new byte[avg];
                    entry = new ZipEntry(Path.Combine(parentFolderName, Path.GetFileName(folderToZip) + "/" + Path.GetFileName(file)));
                    entry.DateTime = DateTime.Now;
                    entry.Size = fs.Length;
                    zipOutputStream.PutNextEntry(entry);
                    for (int i = 0; i < fs.Length; i += avg)
                    {
                        if (i + avg > fs.Length)
                            //不足100MB的部分写剩余部分
                            buffer = new byte[fs.Length - i];
                        fs.Read(buffer, 0, buffer.Length);
                        zipOutputStream.Write(buffer, 0, buffer.Length);
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                result = false;
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs = null;
                }
                if (entry != null)
                    entry = null;
                GC.Collect();
                GC.Collect(1);
            }
            folders = Directory.GetDirectories(folderToZip);
            foreach (string folder in folders)
            {
                if (!ZipFileDictory(folder, zipOutputStream, Path.Combine(parentFolderName, Path.GetFileName(folderToZip))))
                    result = false;
            }
            return result;
        }
    }
}