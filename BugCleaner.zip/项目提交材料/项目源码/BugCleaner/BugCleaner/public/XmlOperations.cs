﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;

namespace ThinkGeo.BugChecker
{
    public static class XmlOperations
    {
        /// <summary>
        /// 组合xpath路径
        /// </summary>
        /// <param name="xpaths">要组合的路径集</param>
        /// <returns>组合好的路径</returns>
        public static string Combine(params string[] xpaths)
        {
            string xPath = "";
            foreach (string xpath in xpaths)
            {
                xPath += R.XpathSeparator + xpath;
            }
            return xPath;
        }

        /// <summary>
        /// 新建xml文件
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="root">根节点名</param>
        public static bool Create(string path, string root)
        {
            FileOperation.CreateFileAndDir(path);
            bool isSuccess = true;
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.Encoding = new UTF8Encoding(false);
            settings.NewLineChars = Environment.NewLine;
            try
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(path, settings))
                {
                    xmlWriter.WriteStartDocument(false);

                    //写根节点
                    xmlWriter.WriteStartElement(root);

                    //根节点闭合
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndDocument();
                }

            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                isSuccess = false;
            }
            return isSuccess;
        }

        /// <summary>
        ///  添加(子节点+内容) 
        ///  ex: <child>content</child>
        ///  不含某属性的节点 -->//node[@attr=null]
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">父节点的xPath路径[形如:"//"+父节点名+"//"+本节点名+"["+位次+"]"]</param>
        /// <param name="newNodeName">新节点的名字</param>
        /// <param name="content">新节点的内容(可为"")</param>
        public static void AddNodeWithContent(string path, string node, string newNodeName, string content)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode parent = null;
            XmlElement newNode = null;
            try
            {
                xmlDoc.Load(path);

                //"//Root//Winforms_Desktop_Edition//Project[@ProjectName=desktopeditionsample_snaptolayer_cs_091209]"
                parent = xmlDoc.SelectSingleNode(node);

                //xml节点不能有空格
                newNode = xmlDoc.CreateElement(newNodeName);
                newNode.InnerText = content;
                parent.AppendChild(newNode);
                xmlDoc.Save(path);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        /// 添加(子节点+属性)
        /// <child attr="attr">content</child>
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">父节点的xpath</param>
        /// <param name="newNodeName">新节点名</param>
        /// <param name="kvs">属性名/值</param>
        public static void AddNodeWithAttribute(string path, string node, string newNodeName, Dictionary<string, string> kvs)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode parent = null;
            XmlElement newNode = null;
            try
            {
                xmlDoc.Load(path);
                parent = xmlDoc.SelectSingleNode(node);

                //xml节点不能有空格
                newNode = xmlDoc.CreateElement(newNodeName);

                //添加属性
                foreach (string key in kvs.Keys)
                {
                    newNode.SetAttribute(key, kvs[key]);
                }
                parent.AppendChild(newNode);
                xmlDoc.Save(path);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        /// 为位于xPath的节点的增加属性
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">xml节点</param>
        /// <param name="key">节点名</param>
        /// <param name="value">节点值</param>
        /// <returns>是否增加成功</returns>
        public static bool AddAttribute(string path, string node, string key, string value)
        {
            bool isSuccess = true;
            XmlDocument xmlDoc = new XmlDocument();
            XmlElement child = null;
            try
            {
                xmlDoc.Load(path);

                //获取节点
                child = (XmlElement)xmlDoc.SelectSingleNode(node);

                //设置或新增属性
                child.SetAttribute(key, value);
                xmlDoc.Save(path);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                isSuccess = false;
                Console.WriteLine("setChildNumber failed!!!");
            }
            return isSuccess;
        }
        
        /// <summary>
        /// 获得父节点的直接孩子总数个数; 包括了注释节点;
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">父节点</param>
        /// <returns>失败返回-1，没有孩子返回0</returns>
        public static int StatisticsAllChildsOfOneNode(string path, string node)
        {

            XmlDocument xmlDoc = new XmlDocument();
            XmlElement parent = null;
            int count = -1;
            try
            {
                xmlDoc.Load(path);
                parent = (XmlElement)xmlDoc.SelectSingleNode(node);
                count = parent.ChildNodes.Count;
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                Console.WriteLine("StatisticsOneNodeChilds " + node + " failed!!!");
            }
            return count;
        }

        /// <summary>
        /// 统计父节点的指定名称的孩子节点的总数，不论孩子的位置;
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">父节点</param>
        /// <param name="childName">指定的孩子节点的名称</param>
        public static int StatisticsSpecificChildsOfOneNode(string path, string node, string childName)
        {

            XmlDocument xmlDoc = new XmlDocument();
            XmlNodeList nodeList = null;
            int count = -1;
            try
            {
                xmlDoc.Load(path);
                nodeList = xmlDoc.SelectNodes(node + "//" + childName);
                count = nodeList.Count;
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return count;
        }

        /// <summary>
        /// 获得位于xPath节点名为key属性的值;
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">xml节点</param>
        /// <param name="key">属性名</param>
        /// <returns>属性值</returns>
        public static string GetAttribute(string path, string node, string key)
        {
            string value = null;
            XmlDocument xmlDoc = new XmlDocument();
            XmlElement node1 = null;
            try
            {
                xmlDoc.Load(path);
                node1 = (XmlElement)xmlDoc.SelectSingleNode(node);
                value = node1.GetAttribute(key);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                Console.WriteLine("GetAttribute " + key + " failed!!!");
            }
            return value;
        }

        /// <summary>
        /// 获取某个节点的所有直接孩子节点的名字Name
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">父节点的xpath路径</param>
        /// <returns>返回一个可以遍历的列表</returns>
        public static IEnumerable<string> GetChildsNameList(string path, string node)
        {
            List<string> childsNameList = new List<string>();
            XmlElement parent = null;
            XmlNodeList childNodesList = null;
            XmlDocument xdoc = new XmlDocument();
            try
            {
                xdoc.Load(path);
                parent = (XmlElement)xdoc.SelectSingleNode(node);
                childNodesList = parent.ChildNodes;
                foreach (XmlNode node1 in childNodesList)
                {
                    childsNameList.Add(node1.Name);
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                Console.WriteLine("getChildsName Failed!!!");
            }
            return childsNameList;
        }

        /// <summary>
        /// 获取某一个节点的所有子节点的内容
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">父节点</param>
        /// <returns>子节点的内容集</returns>
        public static IEnumerable<string> GetOneNodeChildsContent(string path, string node)
        {
            List<string> childsContentList = new List<string>();
            XmlElement parent = null;
            XmlNodeList childNodesList = null;
            XmlDocument xdoc = new XmlDocument();
            try
            {
                xdoc.Load(path);
                parent = (XmlElement)xdoc.SelectSingleNode(node);
                childNodesList = parent.ChildNodes;
                foreach (XmlNode node1 in childNodesList)
                {
                    childsContentList.Add(node1.InnerText);
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return childsContentList;
        }

        /// <summary>
        /// 获取某个节点的内容
        /// </summary>
        /// <param name="path">文件路径</param>
        /// <param name="node">xml节点</param>
        /// <returns>节点内容</returns>
        public static string GetOneNodeContent(string path, string node)
        {
            XmlElement xnode = null;
            XmlDocument xdoc = new XmlDocument();
            string content = string.Empty;
            try
            {
                xdoc.Load(path);
                xnode = (XmlElement)xdoc.SelectSingleNode(node);
                content = xnode.InnerText;
            }
            catch (XPathException e)
            {
                throw e;
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return content;
        }
        
        /// <summary>
        /// 判断某个xpath路径下是否有节点
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">xml节点</param>
        /// <returns>是否有节点</returns>
        public static bool HasNode(string path, string node)
        {
            XmlElement xe = null;
            XmlDocument xdoc = new XmlDocument();
            bool hasIt = true;
            try
            {
                xdoc.Load(path);
                xe = (XmlElement)xdoc.SelectSingleNode(node);
                if (xe == null)
                {
                    hasIt = false;
                }
            }
            catch (XPathException e)
            {
                throw e;
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return hasIt;
        }

        /*
        #节点名字
        #节点名字+属性 
            使用：(xpath)
        <node a="a"></node>
        #节点名字+内容  
            使用：(xpath+遍历子节点内容)
        <node>content</node>
        */

        /// <summary>
        /// 判断节点是否存在 
        /// <node></node>
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">xml节点</param>
        /// <returns>节点是否存在</returns>
        public static bool ExistNodeWithNameOrAttr(string path, string node)
        {
            bool exist = false;
            XmlDocument xmlDoc = new XmlDocument();
            XmlNode xn = null;
            try
            {
                xmlDoc.Load(path);
                xn = xmlDoc.SelectSingleNode(node);
                exist = (xn != null) ? true : false;
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return exist;
        }

        /// <summary>
        /// 判断节点是否存在
        ///  <node>content</node>
        /// </summary>
        /// <param name="path">xml文件路径</param>
        /// <param name="node">节点的父节点的xpath</param>
        /// <param name="content">节点内容</param>
        /// <returns>节点是否存在</returns>
        public static bool ExistNodeWithContent(string path, string node, string content)
        {
            bool exist = false;
            XmlDocument xmlDoc = new XmlDocument();
            try
            {
                xmlDoc.Load(path);
                foreach (string childContent in GetOneNodeChildsContent(path, node))
                {
                    if (childContent.Equals(content))
                    {
                        exist = true;
                        break;
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return exist;
        }

        /// <summary>
        ///  拼凑xpath中属性的字符串
        ///  比如: /bookstore/book[id='4']  
        /// </summary>
        /// <returns>拼凑结果</returns>
        public static string XpathAttributeWrap(string key, string value)
        {
            return "[" + "@" + key + "='" + value + "']";
        }        
    }
}
