﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;

namespace ThinkGeo.BugChecker
{
    public static class FileOperation
    {

        /*文件流基本操作*/
        /// <summary>
        /// 把本机文件流或网络文件流转换为可操作流 MemoryStream
        /// </summary>
        /// <param name="stream">本机文件流或网络文件流</param>
        /// <param name="length">length文件片段长度;length=0整个文件</param>
        /// <returns>转换后的可操作流</returns>
        public static MemoryStream ChangeStreamToMemoryStream(Stream stream, long length)
        {
            var buffer = new byte[5000];
            try
            {
                if (length == 0)
                {
                    using (var outStream = new MemoryStream())
                    {
                        int count; //实际读取数;

                        //全部读取;
                        //stream --> buffer
                        while ((count = stream.Read(buffer, 0, buffer.Length)) != 0)
                        {
                            //bytes --> outStream
                            outStream.Write(buffer, 0, count);
                        }
                        return outStream;
                    }
                }
                else
                {
                    buffer = new byte[length];
                    using (var outStream = new MemoryStream())
                    {
                        //读取len个;
                        //stream --> buffer
                        for (int i = 0; i < length; i++)
                        {
                            buffer[i] = (byte)stream.ReadByte();
                        }
                        //buffer --> memorystream
                        outStream.Write(buffer, 0, buffer.Length);

                        return outStream;
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                return null;
            }
        }

        /// <summary>
        ///  根据文件流的字节数,判断本地文件和远程文件是否相同;
        /// </summary>
        /// <param name="url">压缩文件的下载地址</param>
        /// <param name="localFilePath">本地文件地址</param>
        /// <returns>是否相同</returns>
        public static bool CompareByLength(string url, string localFilePath)
        {
            long a = -1, b = -1;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    //向服务器请求，获得服务器的回应数据流
                    using (var stream = response.GetResponseStream())
                    {
                        a = response.ContentLength;
                        b = a;
                    }
                }

                using (FileStream fs = new FileStream(localFilePath, FileMode.Open))
                {
                    b = fs.Length;
                }

            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return a == b;
        }

        /// <summary>
        /// 递归 获取文件夹下的所有指定后缀名的文件
        /// ==>升级版 //获取指定后缀-->获取后缀包含指定字符串
        /// </summary>
        /// <param name="dirPath">文件夹路径</param>
        /// <param name="pattern">后缀名-->("*.exe")</param>
        /// <param name="filesList">文件全路径集合</param>
        public static void GetFilesWithExt(string dirPath, string pattern, ref IList<string> filesList)
        {
            DirectoryInfo directory = new DirectoryInfo(dirPath);
            if (directory.Exists || pattern.Trim() != string.Empty)
            {
                try
                {
                    foreach (FileInfo info in directory.GetFiles(pattern))
                    {
                        filesList.Add(info.FullName.ToString());
                    }
                }
                catch (IndexOutOfRangeException e)
                {
                    HandleException.WirteLog(e.Message, e.StackTrace);
                }
                foreach (DirectoryInfo info in directory.GetDirectories())
                {
                    GetFilesWithExt(info.FullName, pattern, ref filesList);
                }
            }
        }

        /*delete*/
        /// <summary>
        /// 删除目录
        /// </summary>
        /// <param name="targetDir">目的目录</param>
        public static void DeleteDirectory(string targetDir)
        {
            string[] files = Directory.GetFiles(targetDir);
            string[] dirs = Directory.GetDirectories(targetDir);

            foreach (string file in files)
            {
                File.SetAttributes(file, FileAttributes.Normal);
                File.Delete(file);
            }

            foreach (string dir in dirs)
            {
                DeleteDirectory(dir);
            }

            Directory.Delete(targetDir, false);
        }

        /// <summary>
        /// 获取bin的父目录
        /// </summary>
        /// <returns>bin的父目录</returns>
        public static string GetParentDirOfBin()
        {
            //Debug目录的路径; 
            //C:\\Users\\didi\\Desktop\\new_crawler\\task\\Compile\\Decompression\\Decompression\\bin\\Debug
            string currentDir = Environment.CurrentDirectory.ToString();

            string binDir = Directory.GetParent(currentDir).ToString();

            //bin的父目录;
            //C:\\Users\\didi\\Desktop\\new_crawler\\task\\Compile\\Decompression\\Decompression"
            string parentDirOfBin = Directory.GetParent(binDir).ToString();

            return parentDirOfBin;
        }

        /// <summary>
        /// 创建文件及其所在目录
        /// </summary>
        /// <param name="fileOrDirPath">路径字符串</param>
        public static void CreateFileAndDir(string fileOrDirPath)
        {

            if (File.Exists(fileOrDirPath) || Directory.Exists(fileOrDirPath))
            {
                return;
            }
            try
            {
                string parentDir = Directory.GetParent(fileOrDirPath).ToString();

                //创建所有上级目录;
                string[] array = parentDir.Split(R.Sep());
                string path = array.First();
                for (int i = 1; i < array.Length; i++)
                {
                    path = MyPath.Combine(path, array[i]);
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                }

                //创建末级文件或目录
                string lastPath = fileOrDirPath.Split(R.Sep()).Last();
                if (lastPath.IndexOf(R.DOT) == lastPath.LastIndexOf(R.DOT) && lastPath.IndexOf(R.DOT) >= 0)
                {
                    FileStream fs = new FileStream(fileOrDirPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
                    fs.Close();
                    fs.Dispose();
                }
                else//文件夹
                {
                    if (!Directory.Exists(fileOrDirPath))
                    {
                        Directory.CreateDirectory(fileOrDirPath);
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }

        }

        /*复制移动文件夹*/
        /// <summary>
        ///  将指定文件夹的所有内容复制到目标文件夹
        ///   1.如果目标文件夹为只读属性就会报错。
        ///   2.覆盖同名文件/夹;
        /// </summary>
        /// <param name="srouceDir">源目录</param>
        /// <param name="targetDir">目的目录</param>
        public static void CopyDir(string srouceDir, string targetDir)
        {
            //"F:\\WPF_Desktop_Edition\\desktopeditionsample_centeringmapwithtolerance_cs_100114\\"
            //"F:\\T\\Map Suite Wpf Desktop\\desktopeditionsample_centeringmapwithtolerance_cs_100114\\"
            try
            {
                // 检查目标目录是否以目录分割字符结束如果不是则添加之
                if (targetDir[targetDir.Length - 1] != Path.DirectorySeparatorChar)
                    targetDir += Path.DirectorySeparatorChar;

                // 判断目标目录是否存在如果不存在则新建之
                if (!Directory.Exists(targetDir))
                {
                    CreateFileAndDir(targetDir);
                }

                // 得到源目录的文件列表，该里面是包含文件以及目录路径的一个数组
                // 如果你指向copy目标文件下面的文件而不包含目录请使用下面的方法
                // string[] fileList = Directory.GetFiles(srcPath);
                string[] fileList = Directory.GetFileSystemEntries(srouceDir);

                // 遍历所有的文件和目录
                foreach (string file in fileList)
                {
                    // 先当作目录处理如果存在这个目录就递归Copy该目录下面的文件
                    if (Directory.Exists(file))
                    {
                        CopyDir(file, targetDir + Path.GetFileName(file));
                    }
                    // 否则直接Copy文件
                    else
                    {
                        //覆盖同名
                        File.Copy(file, targetDir + Path.GetFileName(file), true);
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }
    }
}
