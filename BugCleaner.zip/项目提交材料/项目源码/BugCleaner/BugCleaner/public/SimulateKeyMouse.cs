﻿using System.Windows.Forms;

namespace ThinkGeo.BugChecker
{
    public class SimulateKeyMouse
    {
        [System.Runtime.InteropServices.DllImport("user32")]
        public static extern int mouse_event(MouseMoving dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        /// <summary>
        /// 模拟鼠标单击(x,y)
        /// 用于获得焦点到vs
        /// </summary>
        /// <param name="x">坐标X</param>
        /// <param name="y">坐标Y</param>
        public static void MouseClick(int x, int y)
        {
            mouse_event(MouseMoving.MOUSEEVENTF_ABSOLUTE | MouseMoving.MOUSEEVENTF_LEFTDOWN | MouseMoving.MOUSEEVENTF_LEFTUP, x, y, 0, 0);
            mouse_event(MouseMoving.MOUSEEVENTF_ABSOLUTE | MouseMoving.MOUSEEVENTF_LEFTDOWN | MouseMoving.MOUSEEVENTF_LEFTUP, x, y, 0, 0);
            System.Threading.Thread.Sleep(100);
        }

        /// <summary>
        /// 鼠标左键双击当前位置
        /// </summary>
        public static void LeftMouseDoubleClick()
        {

            //鼠标左键点击
            mouse_event(MouseMoving.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            mouse_event(MouseMoving.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);

            //鼠标左键点击
            mouse_event(MouseMoving.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            mouse_event(MouseMoving.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
        }

        //鼠标移动到目的位置;
        [System.Runtime.InteropServices.DllImport("user32")]
        public static extern bool SetCursorPos(int X, int Y);

        /// <summary>
        /// 模拟输入一般的字符串
        /// </summary>
        /// <param name="s">输入的字符串</param>
        public static void SendString(string s)
        {
            SendKeys.SendWait(s);
            System.Threading.Thread.Sleep(100);
            SendKeys.Flush();
        }
    }
}
