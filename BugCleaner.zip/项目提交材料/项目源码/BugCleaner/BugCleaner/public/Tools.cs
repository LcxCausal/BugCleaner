﻿using System;
using System.IO;

namespace ThinkGeo.BugChecker
{
    public class Tools
    {
        /*公用*/
        /// <summary>
        /// 获取bin的父目录
        /// </summary>
        /// <returns>C:\\Users\\didi\\Desktop\\new_crawler\\task\\Compile\\Decompression\\Decompression</returns>
        public static string GetParentDirOfBin()
        {
            //Debug目录的路径;
            //C:\\Users\\didi\\Desktop\\new_crawler\\task\\Compile\\Decompression\\Decompression\\bin\\Debug
            string currentDir = Environment.CurrentDirectory.ToString();

            string binDir = Directory.GetParent(currentDir).ToString();

            //bin的父目录;
            //C:\\Users\\didi\\Desktop\\new_crawler\\task\\Compile\\Decompression\\Decompression"
            return Directory.GetParent(binDir).ToString();
        }

        /// <summary>
        /// 向控制台输出红色字体;
        /// </summary>
        /// <param name="msg"></param>
        public static void WirteRedToConsole(string msg)
        {
            //设置控制台前景色，即字体颜色
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(msg);
            Console.ResetColor();
            Log.WirteLog(msg);
        }
    }
}
