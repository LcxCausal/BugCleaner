﻿using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ThinkGeo.BugChecker
{
    public class ScreenShot
    {
        // 获取当前窗口句柄:GetForegroundWindow(),返回值类型是IntPtr,即为当前获得焦点窗口的句柄
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetForegroundWindow();

        // 获取窗口大小及位置:需要调用方法GetWindowRect(IntPtr hWnd, ref RECT lpRect)
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GetWindowRect(IntPtr hWnd, ref RECT lpRect);
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;    //最左坐标
            public int Top;     //最上坐标
            public int Right;   //最右坐标
            public int Bottom;  //最下坐标 
        }

        /// <summary>
        /// 截取全屏
        /// tested
        /// </summary>
        /// <param name="imgSavePath">截图图片的完整路径,如(aa/bb.jpg)</param>
        public static void ScreenShotFullScreen(string imgSavePath)
        {
            FileOperation.CreateFileAndDir(imgSavePath);
            Graphics g = null;
            try
            {
                Bitmap myImage = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
                g = Graphics.FromImage(myImage);

                //得到图片放入内存
                g.CopyFromScreen(new Point(0, 0), new Point(0, 0), new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height));

                //保存到磁盘
                myImage.Save(imgSavePath);
            }
            catch (InvalidOperationException e)
            {
                string shortMsg = e.Message;
                shortMsg += Environment.NewLine + imgSavePath + Environment.NewLine;
                string stackMsg = e.StackTrace;
                HandleException.WirteLog(shortMsg, stackMsg);
            }
            finally
            {
                //释放资源
                IntPtr dc1 = g.GetHdc();
                g.ReleaseHdc(dc1);
            }
        }

        /// <summary>
        /// 截取指定矩形区域的屏幕
        /// </summary>
        /// <param name="imgSavePath">图像的完整保存路径,如(xxx.jpg)</param>
        /// <param name="rect">矩形区域</param>
        public static void ScreenShotSpecifiedScreen(string imgSavePath, Rectangle rect)
        {
            string imgParentDir = Directory.GetParent(imgSavePath).ToString();
            Bitmap bitmap = null;
            Graphics g = null;
            try
            {
                rect = Screen.GetWorkingArea(rect);
                Size mySize = new Size(rect.Width, rect.Height);
                bitmap = new Bitmap(rect.Width, rect.Height);
                g = Graphics.FromImage(bitmap);

                //得到图片
                g.CopyFromScreen(0, 0, 0, 0, mySize);

                //string ImageName = DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".jpg";
                if (!Directory.Exists(imgParentDir))
                {
                    Directory.CreateDirectory(imgParentDir);
                }
                bitmap.Save(imgSavePath);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            finally
            {
                //释放资源  
                bitmap.Dispose();
                g.Dispose();
                GC.Collect();
            }
        }

    }

}
