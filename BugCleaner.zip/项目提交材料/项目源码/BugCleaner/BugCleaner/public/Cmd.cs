﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace ThinkGeo.BugChecker
{
    /// <summary>
    /// 调用cmd命令
    /// </summary>
    public static class Cmd
    {
        public static void PrintCmdOutput(string exeName)
        {
            //进程名转小写
            exeName = exeName.ToLower();
            Process[] processes = Process.GetProcessesByName(exeName);
            foreach (Process process in processes)
            {
                Console.WriteLine("Process Name: {0}, Id {1}, out put : ", exeName, process.Id);
                StreamReader reader = process.StandardOutput;
                string line = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    Console.WriteLine(line);
                    line = reader.ReadLine();
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// 判断exe是否运行,任务管理器可以看到
        /// </summary>
        /// <param name="exeName">exe的名字</param>
        /// <returns>exe是否运行</returns>
        public static bool IsExeRun(string exeName)
        {
            bool isExeRun = false;
            exeName = exeName.ToLower();
            Process[] processs = Process.GetProcessesByName(exeName);
            foreach (Process pro in processs)
            {
                try
                {
                    string proName = pro.ProcessName.ToLower().Trim();

                    //判断是否包含阻碍更新的进程
                    if (proName.Equals(exeName))
                    {
                        isExeRun = true;
                        break;
                    }
                }
                catch (InvalidOperationException e)
                {
                    HandleException.WirteLog(e.Message, e.StackTrace);
                }
            }
            return isExeRun;
        }


        /// <summary>
        /// 调用cmd.exe执行cmd命令,但是不获取cmd窗口的输出; 一般用于使用cmd打开某个程序
        /// </summary>
        /// <param name="command">cmd窗口中应该输入的命令</param>
        /// <param name="cmdExe">cmd.exe的路径</param>
        public static void RunCmdNoOut(string command, string cmdExe)
        {
            Process p = new Process();

            // "cmd.exe";
            //要启动的应用程序;
            p.StartInfo.FileName = cmdExe;

            //是否使用操作系统shell启动
            p.StartInfo.UseShellExecute = false;

            //接受来自调用程序的输入信息
            p.StartInfo.RedirectStandardInput = true;

            //由调用程序获取输出信息
            p.StartInfo.RedirectStandardOutput = true;

            //重定向标准错误输出
            p.StartInfo.RedirectStandardError = true;

            //不显示程序窗口
            p.StartInfo.CreateNoWindow = true;

            //启动程序
            p.Start();

            //向cmd窗口发送输入信息
            p.StandardInput.WriteLine(command + "&exit");
            p.StandardInput.AutoFlush = true;

            //等待外部程序执行完退出当前进程,这里无限等待启动外部进程结束
            p.WaitForExit();
            p.Close();
        }

        /// <summary>
        ///  运行需要切换到父目录的exe,
        /// </summary>
        /// <param name="exePath">要运行的exe文件路径</param>
        public static void RunCdExe(string exePath)
        {
            Process p = new Process();
            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.CreateNoWindow = false;

            try
            {
                p.Start();

                //向cmd窗口发送输入信息
                p.StandardInput.AutoFlush = true;

                //切换路径
                string parentDir = Directory.GetParent(exePath).ToString();
                string command = string.Format("{0} {1} \"{2}\"", "cd", "/d", parentDir);
                p.StandardInput.WriteLine(command);

                //运行exe
                string exeName = exePath.Split(R.Sep()).Last();
                command = exeName;
                p.StandardInput.WriteLine(command);
                p.StandardInput.WriteLine("exit");

                //等待程序执行完退出进程
                p.WaitForExit();
                p.Close();
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        /// 执行cmd命令,返回cmd窗口的输出;
        /// </summary>
        /// <param name="command">完整的cmd命令</param>
        /// <param name="cmdExe">cmd.exe所在的路径</param>
        /// <param name="MaxTime">cmd窗口执行时限</param>
        /// <returns>cmd运行结果输出信息</returns>
        public static string RunCmdGetOutput(string command, string cmdExe, int MaxTime)
        {
            string output = "";
            try
            {
                Process p = new Process();

                //要启动的应用程序;
                p.StartInfo.FileName = cmdExe;

                //是否使用操作系统shell启动
                p.StartInfo.UseShellExecute = false;

                //接受来自调用程序的输入信息
                p.StartInfo.RedirectStandardInput = true;

                //由调用程序获取输出信息
                p.StartInfo.RedirectStandardOutput = true;

                //重定向标准错误输出
                p.StartInfo.RedirectStandardError = true;

                //不显示程序窗口
                p.StartInfo.CreateNoWindow = true;

                //启动程序
                p.Start();

                //向cmd窗口发送命令
                p.StandardInput.WriteLine(command + "&exit");
                p.StandardInput.AutoFlush = true;

                //获取cmd窗口的输出信息
                StreamReader reader = p.StandardOutput;
                string line = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    output += line + "  ";
                    line = reader.ReadLine();
                }

                //等待程序执行完退出进程
                p.WaitForExit(MaxTime);
                p.Close();
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return output;
        }

        /// <summary>
        /// 根据进程名关闭进程,进程在方法内转为小写;
        /// </summary>
        /// <param name="exeName">进程名</param>
        public static void ShutDown(string exeName)
        {
            exeName = exeName.ToLower();
            Process[] processes = Process.GetProcessesByName(exeName);
            foreach (Process process in processes)
            {
                try
                {
                    string proName = process.ProcessName.ToLower().Trim();

                    //判断是否包含阻碍更新的进程
                    if (proName.Equals(exeName))
                    {
                        process.Kill();
                    }
                }
                catch (InvalidOperationException e)
                {
                    HandleException.WirteLog(e.Message, e.StackTrace);
                }
            }
        }
    }
}
