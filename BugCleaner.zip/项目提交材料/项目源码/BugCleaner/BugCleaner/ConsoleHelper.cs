﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace ThinkGeo.BugChecker
{
    public static class ConsoleHelper
    {
        /// <summary>
        /// 隐藏指定窗体,到任务栏
        /// </summary>
        /// <param name="consoleTitle"></param>
        public static void HideConsole(string consoleTitle)
        {
            IntPtr ParenthWnd = new IntPtr(0);
            IntPtr et = new IntPtr(0);
            ParenthWnd = FindWindow(null, consoleTitle);
            //隐藏本dos窗体, 0: 后台执行；1:正常启动；2:最小化到任务栏；3:最大化
            ShowWindow(ParenthWnd, 2);
        }

        /// <summary>
        /// 显示指定窗体
        /// </summary>
        /// <param name="consoleTitle"></param>
        public static void ShowConsole(string consoleTitle)
        {
            IntPtr ParenthWnd = new IntPtr(0);
            IntPtr et = new IntPtr(0);
            ParenthWnd = FindWindow(null, consoleTitle);
            // 0: 后台执行；1:正常启动；2:最小化到任务栏；3:最大化
            ShowWindow(ParenthWnd, 3);
        }

        [DllImport("User32.dll", EntryPoint = "FindWindow")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        //找子窗体   
        [DllImport("user32.dll", EntryPoint = "FindWindowEx")]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        //用于发送信息给窗体   
        [DllImport("User32.dll", EntryPoint = "SendMessage")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, string lParam);

        [DllImport("User32.dll", EntryPoint = "ShowWindow")]
        private static extern bool ShowWindow(IntPtr hWnd, int type);

    }
}
