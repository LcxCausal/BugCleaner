﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ThinkGeo.BugChecker
{
    public class Crawler
    {
        private bool isStart;
        private bool isFinish;
        //爬虫结束时间(h:m:s)
        private string crawlerEndTime = "0:0:0";

        private object sycObj = new object();

        //待下载的url队列;
        private ConcurrentQueue<Url> unloadUrlQueue = new ConcurrentQueue<Url>();

        //正在处理的url集合;
        private HashSet<Url> downloadingSet = new HashSet<Url>();

        //已经爬取过的链接的集合
        private HashSet<Url> hasDownloadedSet = new HashSet<Url>();

        //压缩包的下载信息的集合;
        private HashSet<Url> zipsSet = new HashSet<Url>();

        public ConcurrentQueue<Url> UnloadUrlQueue
        {
            get { return unloadUrlQueue; }
        }

        public HashSet<Url> DownloadingSet
        {
            get { return downloadingSet; }
        }

        public HashSet<Url> HasDownloadedSet
        {
            get { return hasDownloadedSet; }
        }

        public HashSet<Url> ZipsSet
        {
            get { return zipsSet; }
        }

        public string CrawlerEndTime
        {
            get
            {
                return crawlerEndTime;
            }

            set
            {
                crawlerEndTime = value;
            }
        }

        public bool IsStart
        {
            get
            {
                lock (sycObj)
                {
                    return isStart;
                }
            }

            set
            {
                lock (sycObj)
                {
                    isStart = value;
                }
            }
        }

        public bool IsFinish
        {
            get
            {
                lock (sycObj)
                {
                    return isFinish;
                }
            }

            set
            {
                lock (sycObj)
                {
                    isFinish = value;
                }
            }
        }

        /// <summary>
        /// 开始爬取
        /// </summary>
        /// <returns>是否爬取完成</returns>
        public void StartupCrawler()
        {
            //处理首页 --(开始和结束时)队列空导致线程结束
            DealWithHomePage();

            //爬取
            TaskFactory taskFactory = new TaskFactory();
            Task[] tasks = new Task[Config.threadsNumber];
            for (int i = 0; i < Config.threadsNumber; i++)
            {
                tasks[i] = taskFactory.StartNew(() =>
                {
                    CrawlerTask();
                }, TaskCreationOptions.AttachedToParent);
            }

            //存入文件
            taskFactory.ContinueWhenAll(tasks, (Task[] t) =>
            {
                if (CrawlerSaveToXml(t))
                {
                    Console.WriteLine("CrawlerSaveToXml success!");
                    Log.WirteLog("CrawlerSaveToXml success!");
                    isFinish = true;
                }
                else
                {
                    Console.WriteLine("CrawlerSaveToXml failed! ");
                    Log.WirteLog("CrawlerSaveToXml failed! ");
                    isFinish = false;
                    StartupCrawler();
                }
            }, TaskContinuationOptions.AttachedToParent);
        }

        /// <summary>
        /// 保存链接信息到xml文件;
        /// </summary>
        private bool CrawlerSaveToXml(Task[] obj)
        {
            bool isSuccess = false;
            try
            {
                //爬虫结果文件;
                string xmlPath = Config.crawlerResultFilePath;

                //zipsSet集合中的zip信息写入xml文件;
                FileOperation.CreateFileAndDir(xmlPath);
                if (File.Exists(xmlPath))
                {
                    File.Delete(xmlPath);
                }
                XmlOperations.Create(xmlPath, R.CrawlerResultRootNODE);
                HashSet<string> hasAdded = new HashSet<string>();
                string category = null;
                string xPath = null;
                foreach (Url url in ZipsSet)
                {
                    xPath = XmlOperations.Combine(R.CrawlerResultRootNODE);
                    category = url.Category.Replace(" ", "_");

                    // 添加分类节点
                    if (!hasAdded.Contains(category))
                    {
                        XmlOperations.AddNodeWithContent(xmlPath, xPath, category, "");
                        hasAdded.Add(category);
                    }

                    // 添加Zip节点到各分类节点
                    // "//" + R.XML_CATEGORY + "//" + category;
                    xPath = XmlOperations.Combine(R.CrawlerResultRootNODE, category);
                    XmlOperations.AddNodeWithContent(xmlPath, xPath, R.Zip, url.AbsoluteUrl);
                }

                //统计并写入属性:各分类孩子总数
                int childsCount = 0;
                foreach (string categ in hasAdded)
                {
                    // "//" + R.XML_CATEGORY + "//" + categ;
                    xPath = XmlOperations.Combine(R.CrawlerResultRootNODE, categ);
                    childsCount = XmlOperations.StatisticsAllChildsOfOneNode(xmlPath, xPath);
                    XmlOperations.AddAttribute(xmlPath, xPath, R.ChildsNumber, childsCount.ToString());
                }

                //统计分类数目,作为属性;
                // "//" + R.XML_CATEGORY;
                xPath = XmlOperations.Combine(R.CrawlerResultRootNODE);
                childsCount = XmlOperations.StatisticsAllChildsOfOneNode(xmlPath, xPath);
                XmlOperations.AddAttribute(xmlPath, xPath, R.CategoryNumber, childsCount.ToString());

                //统计总共的zips的数量，并作为属性写入xml;
                // "//" + R.XML_CATEGORY;
                xPath = XmlOperations.Combine(R.CrawlerResultRootNODE);
                childsCount = XmlOperations.StatisticsSpecificChildsOfOneNode(xmlPath, xPath, R.Zip);
                XmlOperations.AddAttribute(xmlPath, xPath, R.ZipsNum, childsCount.ToString());
                isSuccess = true;
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return isSuccess;
        }

        /// <summary>
        ///  处理入口地址,获取
        ///  1.分类信息
        ///  2.下级线索
        /// </summary>
        private void DealWithHomePage()
        {
            Url startUrl = new Url(Config.entryUrl, "随便", 1);

            //获取url对应的解析器
            HtmlParserContext parserContext = new HtmlParserContext();

            CrawlerRule rule;
            Config.rulesDictonary.TryGetValue(startUrl.Depth, out rule);
            parserContext.CreateHtmlParser(startUrl, rule);

            //任务工厂执行爬取
            IList<Url> sub_urls = parserContext.GetSubHrefsWithFilter(startUrl);
            Add(HasDownloadedSet, startUrl);
            foreach (Url u in sub_urls)
            {
                Add(UnloadUrlQueue, u);
            }
        }

        private void CrawlerTask()
        {
            string type = string.Empty;
            while (true)
            {
                //弹出Url;
                Url url;
                lock (sycObj)
                {
                    //弹出成功;
                    if (UnloadUrlQueue.TryDequeue(out url))
                    {
                        Add(DownloadingSet, url);
                    }
                    //队列空弹出失败,url为null
                    else
                    {
                        Thread.Sleep(100);
                        if (DownloadingSet.Any())
                        {
                            continue;
                        }
                        else
                        {
                            return;
                        }
                    }
                }

                //获取url对应的解析器
                HtmlParserContext parserContext = new HtmlParserContext();
                CrawlerRule rule;
                Config.rulesDictonary.TryGetValue(url.Depth, out rule);
                parserContext.CreateHtmlParser(url, rule);

                //调用自适应的爬虫
                try
                {
                    // 获取下级线索
                    IList<Url> sub_urls = parserContext.GetSubHrefsWithFilter(url);

                    Add(HasDownloadedSet, url);

                    //没有下级线索,则退出本次循环
                    if (sub_urls == null) { continue; }

                    //#处理下级线索
                    foreach (Url u in sub_urls)
                    {
                        //纪录处理的链接到日志
                        Log.WirteLog(u.ToString());
                        if (url.Depth == 4)
                            //下级线索是目标url
                            Add(ZipsSet, u);
                        else
                            //否则将下级线索排队
                            Add(UnloadUrlQueue, u);
                    }
                }
                catch (InvalidOperationException e)
                {
                    HandleException.WirteLog(e.Message, e.StackTrace);

                    //抛异常，爬取失败
                    Add(UnloadUrlQueue, url);
                }
                finally
                {
                    //即使是continue也会执行这句;
                    Remove(DownloadingSet, url);
                }
            }
        }

        public void Add(IEnumerable<Url> collection, Url url)
        {
            Type type = collection.GetType();
            object obj1 = Convert.ChangeType(collection, collection.GetType());
            if (obj1 is HashSet<Url>)
            {
                lock (sycObj)
                {
                    HashSet<Url> hs = (HashSet<Url>)collection;
                    hs.Add(url);
                }
            }
            if (obj1 is ConcurrentQueue<Url>)
            {
                lock (sycObj)
                {
                    ConcurrentQueue<Url> queue = (ConcurrentQueue<Url>)collection;
                    queue.Enqueue(url);
                }
            }
        }

        private void Remove(IEnumerable<Url> collection, Url url)
        {

            Type type = collection.GetType();
            object obj1 = Convert.ChangeType(collection, collection.GetType());
            if (obj1 is HashSet<Url>)
            {
                lock (sycObj)
                {
                    HashSet<Url> hs = (HashSet<Url>)collection;
                    hs.Remove(url);
                }
            }
            if (obj1 is ConcurrentQueue<Url>)
            {
                lock (sycObj)
                {
                    ConcurrentQueue<Url> queue = (ConcurrentQueue<Url>)collection;
                    queue.TryDequeue(out url);
                }
            }
        }
    }
}
