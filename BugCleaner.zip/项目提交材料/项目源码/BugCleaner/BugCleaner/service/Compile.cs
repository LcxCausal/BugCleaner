﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace ThinkGeo.BugChecker
{
    public class Compile
    {
        private bool isStart;
        private bool isFinish;

        //待解压的队列
        public ConcurrentQueue<string> unzipQueue = new ConcurrentQueue<string>();

        public static object sycObj = new object();
        //进度报告时间间隔;
        private int reportInterval = 5000;

        //记录解压进度
        private static int unzipTotalCount = 0;
        private static int unzipSuccessCount = 0;
        private static int unzipFailedCount = 0;

        //记录编译进度
        private static int compileTotalCount = 0;
        private static int compileSuccessCount = 0;
        private static int compileFailedCount = 0;

        private bool isFinishUnzip = false;

        public bool IsFinish
        {
            get { return isFinish; }
        }

        public int ReportInterval
        {
            get { return reportInterval; }
        }

        public static int UnzipTotalCount
        {
            get { return unzipTotalCount; }
        }

        public static int UnzipSuccessCount
        {
            get { return unzipSuccessCount; }
        }

        public static int UnzipFailedCount
        {
            get { return unzipFailedCount; }
        }

        public static int CompileTotalCount
        {
            get { return compileTotalCount; }
        }

        public static int CompilesuccessCount
        {
            get { return compileSuccessCount; }
        }

        public static int CompileFailedCount
        {
            get { return compileFailedCount; }
        }

        public bool IsFinishUnzip
        {
            get { return isFinishUnzip; }
        }

        public bool IsStart
        {
            get
            {
                return isStart;
            }

            set
            {
                isStart = value;
            }
        }

        /// <summary>
        /// 开始编译
        /// </summary>
        public void StartupCompile()
        {
            try
            {
                //解压
                Task t1 = new Task(UnZipAll, TaskCreationOptions.AttachedToParent);
                t1.Start();

                //编译
                Task t2 = t1.ContinueWith((Action<Task>)((Task) =>
                {

                    TaskFactory taskFactory = new TaskFactory(TaskCreationOptions.AttachedToParent, TaskContinuationOptions.AttachedToParent);
                    IList<Task> tasks = new List<Task>();
                    foreach (string projectDir in Directory.GetDirectories(Config.UnZipDirPath))
                    {
                        tasks.Add(taskFactory.StartNew(() =>
                        {
                            TaskCompileAndMoveOneProject(projectDir);
                        }, TaskCreationOptions.AttachedToParent));
                    }
                    taskFactory.ContinueWhenAll(tasks.ToArray(), (Action<Task[]>)((Task[] t) =>
                    {
                        Tools.WirteRedToConsole("Compile finishi");
                        isFinish = true;
                    }), TaskContinuationOptions.AttachedToParent);

                    CompileReport();
                }), TaskContinuationOptions.AttachedToParent);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                StartupCompile();
            }
        }

        /// <summary>
        /// 编译结果报告
        /// </summary>
        private void CompileReport()
        {
            while (!IsFinish)
            {
                lock (sycObj)
                {
                    Console.WriteLine(string.Format("compile Success: {0}/{1}", CompilesuccessCount, CompileTotalCount));
                    Console.WriteLine(string.Format("compile Failed: {0}/{1}", CompileFailedCount, CompileTotalCount));
                }
                Thread.Sleep(ReportInterval);
            }
            lock (sycObj)
            {
                Console.WriteLine(string.Format("compile Success: {0}/{1}", CompilesuccessCount, CompileTotalCount));
                Console.WriteLine(string.Format("compile Failed: {0}/{1}", CompileFailedCount, CompileTotalCount));
            }
        }

        /// <summary>
        /// 1.解压newZips下的压缩包到UnZip目录
        /// </summary>
        private void UnZipAll()
        {
            TaskFactory taskFactory = new TaskFactory();
            IList<Task> tasks = new List<Task>();
            IList<string> zips = new List<string>();
            FileOperation.GetFilesWithExt(Config.downloadZipsDir, R.ExtZip, ref zips);
            unzipTotalCount = zips.Count();
            compileTotalCount = UnzipTotalCount;
            try
            {
                foreach (string zipFile in Directory.GetFiles(Config.downloadZipsDir))
                {
                    Task t = taskFactory.StartNew(() =>
                    {
                        UnZipTask(zipFile);
                    }, TaskCreationOptions.AttachedToParent);
                    tasks.Add(t);
                }
                taskFactory.ContinueWhenAll(tasks.ToArray(), (Task[] t) =>
                {
                    Console.WriteLine("unzip finishi");
                    isFinishUnzip = true;
                }, TaskContinuationOptions.AttachedToParent);
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            UnzipReport();
        }

        private void UnzipReport()
        {
            while (!IsFinishUnzip)
            {
                lock (sycObj)
                {
                    Console.WriteLine(string.Format("unzip Success: {0}/{1}", UnzipSuccessCount, UnzipTotalCount));
                    Console.WriteLine(string.Format("unzip Failed: {0}/{1}", UnzipFailedCount, UnzipTotalCount));
                }
                Thread.Sleep(ReportInterval);
            }
            lock (sycObj)
            {
                Console.WriteLine(string.Format("unzip Success: {0}/{1}", UnzipSuccessCount, UnzipTotalCount));
                Console.WriteLine(string.Format("unzip Failed: {0}/{1}", UnzipFailedCount, UnzipTotalCount));
            }
        }

        /// <summary>
        /// 解压线程的方法
        /// </summary>
        /// <param name="zipFile">压缩包路径</param>
        private void UnZipTask(string zipFile)
        {
            string projectName = ExtractProjectName(zipFile);

            //解压到该目录
            string desDirPath = MyPath.Combine(Config.UnZipDirPath, projectName);
            try
            {
                try
                {
                    if (ZipUnZip.UnZip(zipFile, desDirPath))
                    {
                        Console.WriteLine("UnZip Success:" + Environment.NewLine + zipFile);
                        lock (sycObj)
                        {
                            unzipSuccessCount++;
                        }
                    }
                }
                catch (InvalidOperationException e)
                {
                    lock (sycObj)
                    {
                        unzipFailedCount++;
                    }
                    string shortMsg = e.Message;
                    if (shortMsg.Equals("Unexpected EOF"))
                    {
                        File.Delete(zipFile);
                        Console.WriteLine("UnZip Failed:" + Environment.NewLine + zipFile);
                    }
                    shortMsg = shortMsg + Environment.NewLine + "Delete Damaged Zip" + zipFile;
                    string stackMsg = e.StackTrace;
                    HandleException.WirteLog(shortMsg, stackMsg);
                    Log.WirteLog("unzip Failed \n" + zipFile);
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        /// 提取项目名
        /// </summary>
        /// <param name="filePath">压缩包路径,如: G:\Download\mvcedition_howdoi_cs_141217.zip</param>
        /// <returns>mvcedition_howdoi_cs_141217</returns>
        private string ExtractProjectName(string filePath)
        {
            string projectName = null;
            string fileName = filePath.Split(R.Sep()).Last();
            projectName = fileName.Substring(0, fileName.Length - 4);
            return projectName;
        }

        /// <summary>
        ///  完成单个项目的编译工作
        ///  1. Modify csproj
        ///  2. msbuild
        ///  3. MoveDir
        /// </summary>
        /// <param name="projectPath">项目文件路径</param>
        private void TaskCompileAndMoveOneProject(string projectPath)
        {
            string projectName;
            projectName = projectPath.Split(R.Sep()).Last();

            //modify csproj or vbproj
            ModifyCsproj(projectPath);

            //msbuild(cmd)
            string aimDir = null;
            try
            {
                //获取sln文件,没有则返回,线程结束
                IList<string> slnFiles = new List<string>();
                FileOperation.GetFilesWithExt(projectPath, R.ExtSln, ref slnFiles);

                //没有sln文件的也视为错误,复制文件到F文件夹
                if (!slnFiles.Any())
                {
                    lock (this)
                        compileFailedCount++;
                    aimDir = MyPath.Combine(Config.compileFailedDirPath, projectName);
                    FileOperation.CopyDir(projectPath, aimDir);
                    return;
                }

                string slnFullName = slnFiles.First();

                //如果调用程序路径中有空格时，cmd命令执行失败，可以用双引号括起来 ，在这里两个引号表示一个引号（转义）
                //构造命令行命令;
                string command = string.Format(@"""{0}"" {1}", Config.msbuildExe, slnFullName);
                string outPut = Cmd.RunCmdGetOutput(command, Config.cmdExe, 120000);

                //解析命令行输出,判断是否通过;
                Regex regexSuccessChinese = new Regex("已成功生成");
                Regex regexSuccessEnglish = new Regex(R.BuildSuccess);
                Regex regexFailedChinese = new Regex("生成失败");
                Regex regexFailedEnglish = new Regex(R.BuildFailed);

                //根据编译结果移动文件;
                if (regexSuccessChinese.IsMatch(outPut) || regexSuccessEnglish.IsMatch(outPut))
                {
                    lock (sycObj)
                    {
                        compileSuccessCount++;
                    }
                    //复制文件到Upload文件夹
                    aimDir = MyPath.Combine(Config.compileSuccessDirPath, projectName);
                    try
                    {
                        FileOperation.CopyDir(projectPath, aimDir);
                    }
                    catch (InvalidOperationException e)
                    {
                        HandleException.WirteLog(e.Message, e.StackTrace);
                    }
                }
                else
                {
                    lock (this)
                    {
                        compileFailedCount++;
                    }
                    //# 复制文件到F文件夹
                    aimDir = MyPath.Combine(Config.compileFailedDirPath, projectName);
                    try
                    {
                        FileOperation.CopyDir(projectPath, aimDir);
                    }
                    catch (InvalidOperationException e)
                    {
                        HandleException.WirteLog(e.Message, e.StackTrace);
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        /// 修改每个项目的*.csproj或*.vbproj文件中的dll路径
        /// </summary>
        /// <param name="projectPath">项目所在文件夹</param>
        private void ModifyCsproj(string projectPath)
        {
            //获取项目的项目文件(csproj或者vbproj) 
            //一个项目可能有多个项目文件
            IList<string> allProj = new List<string>(); 
            FileOperation.GetFilesWithExt(projectPath, R.ExtCsproj, ref allProj);
            FileOperation.GetFilesWithExt(projectPath, R.ExtVbproj, ref allProj);
            try
            {
                //修改项目文件中的dll路径
                foreach (string csprojFullName in allProj)
                {
                    IDictionary<string, string> replaceDic = Config.replaceDllDic;

                    //添加项目自带的Dependecies中的dll到dll替换字典
                    IList<string> dependencyDlls = new List<string>();
                    FileOperation.GetFilesWithExt(projectPath, R.ExtDll, ref dependencyDlls);
                    foreach (string dllPath in dependencyDlls)
                    {
                        string dllName = dllPath.Split(R.Sep()).Last().ToLower();
                        lock (sycObj)
                            if (!replaceDic.ContainsKey(dllName))
                                replaceDic.Add(dllName, dllPath);
                    }
                    string nameSpace = "http://schemas.microsoft.com/developer/msbuild/2003";
                    ReplaceDll(csprojFullName, replaceDic, nameSpace);
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        ///  替换csproj文件中的dll路径,即(<HintPath>节点的内容)
        /// </summary>
        /// <param name="fullName">单个.csproj文件或.vbproj文件</param>
        /// <param name="replaceDic">dll替换表</param>
        private bool ReplaceDll(string fullName, IDictionary<string, string> replaceDic, string nameSpace)
        {
            bool isSucceed = true;
            try
            {
                string innerText, dllName, xPath;

                //去除文件的只读属性
                File.SetAttributes(fullName, FileAttributes.Normal); 
                XmlDocument xdoc = new XmlDocument();
                xdoc.Load(fullName);

                //csproj使用了命名空间
                XmlNamespaceManager xnManager = new XmlNamespaceManager(xdoc.NameTable);
                xnManager.AddNamespace("tu", "http://schemas.microsoft.com/developer/msbuild/2003");

                //获取存储dll的信息的节点 
                xPath = R.XpathSeparator + "tu:" + R.HintPath;
                XmlNodeList hintpaths = xdoc.SelectNodes(xPath, xnManager);

                //replace dll
                IList<string> dllsNotExistList = new List<string>();
                for (int i = 0; i < hintpaths.Count; i++)
                {
                    XmlNode xNode = hintpaths[i];
                    innerText = xNode.InnerText;

                    //DLL和dll的统一处理为dll
                    dllName = innerText.Split(R.Sep()).Last().ToLower();

                    lock (sycObj)
                    {
                        if (replaceDic.ContainsKey(dllName))
                            xNode.InnerText = replaceDic[dllName];
                        else
                        {
                            string lackMsg = string.Format("{0}\t{1}", fullName, dllName);
                            RecordLackDll(MyPath.Combine(Config.rootDir, Config.lackDllFile), lackMsg);
                        }
                    }
                    xdoc.Save(fullName);
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                isSucceed = false;
            }
            return isSucceed;
        }

        /// <summary>
        /// 记录缺失的dll信息
        /// </summary>
        /// <param name="filePath">存储信息的文件</param>
        /// <param name="lackMsg">缺失dll的描述</param>
        private void RecordLackDll(string filePath, string lackMsg)
        {
            if (!File.Exists(filePath))
            {
                FileOperation.CreateFileAndDir(filePath);
                string head = string.Format("{0}\t{1}", "Project File Path", "Missing Dll");
                head += "\r\n";
                File.AppendAllText(filePath, head, Encoding.UTF8);
            }
            lock (sycObj)
            {
                File.AppendAllText(filePath, lackMsg + "\r\n", Encoding.UTF8);
            }
        }
    }
}
