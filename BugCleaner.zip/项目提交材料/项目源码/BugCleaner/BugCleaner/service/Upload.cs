﻿using Octokit;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThinkGeo.BugChecker
{
    public class Upload
    {
        private bool isFinish;
        private int uploadTotalCount = 0;
        public static object sycObj = new object();
       
        //已经完成上传动作的数目;包括上传失败的数目;
        private int hasUploadCount = 0;

        //上传失败
        private int uploadFailedCount = 0;
        private IDictionary<string, List<string>> uploadMap = new Dictionary<string, List<string>>();

        public bool IsFinish
        {
            get { return isFinish; }
        }

        public int UploadTotalCount
        {
            get { return uploadTotalCount; }
        }

        public int HasUploadCount
        {
            get { return hasUploadCount; }
        }

        public int UploadFailedCount
        {
            get { return uploadFailedCount; }
        }

        /// <summary>
        /// 本函数为单线程: upload all projects 
        /// </summary>
        public async void StartUpUpload()
        {
            //获取所有项目,并以单个项目为单位依次上传
            string repositoryName;
            try
            {
                IList<string> projectDirs = Directory.GetDirectories(Config.UploadDirPath);
                uploadTotalCount = projectDirs.Count();

                // 删除github网站上的旧版仓库
                for (int i = 0; i < UploadTotalCount; i++)
                {
                    string projectDir = projectDirs[i];
                    //  project' name is repository's name;
                    repositoryName = projectDir.Split(R.Sep()).Last();

                    // create repository, if exist delete first;
                    await DeleteRepository(repositoryName);
                }

                //hide console before upload
                ConsoleHelper.HideConsole("BugChecker");

                // Upload 
                for (int i = 0; i < UploadTotalCount; i++)
                {
                    string projectDir = projectDirs[i];

                    DeleteBinAndObj(projectDir);

                    //  project' name is repository's name;
                    repositoryName = projectDir.Split(R.Sep()).Last();
                    await CreateRepository(repositoryName);

                    // generate the bat file;
                    string batFilePath = GenerateBatFile(projectDir);

                    // if exist .git ,delete it;
                    string gitDir = MyPath.Combine(projectDir, ".git");
                    if (Directory.Exists(gitDir))
                    {
                        FileOperation.DeleteDirectory(gitDir);
                    }

                    // 执行bat文件
                    Process.Start(batFilePath);

                    Log.WirteLog("start upload : " + repositoryName);
                    Thread.Sleep(3000);

                    // 在git push阶段,模拟键盘输入username password
                    SimulateKeyMouse.SetCursorPos(1000, 500);
                    SimulateKeyMouse.MouseClick(1000, 500);
                    SimulateKeyMouse.SendString(Config.GitHubUserName);
                    //Thread.Sleep(5000);
                    SimulateKeyMouse.SendString("{ENTER}");
                    //Thread.Sleep(5000);
                    SimulateKeyMouse.SendString(Config.GitHubPassWord);
                    Thread.Sleep(5000);
                    SimulateKeyMouse.SendString("{ENTER}");
                    Thread.Sleep(10000);

                    // wait the git.exe run
                    int gitCount = 0;
                    while (true)
                    {
                        gitCount = Process.GetProcessesByName("git").Count();
                        Thread.Sleep(8000);
                        if (gitCount > 0)
                        {
                            break;
                        }
                        Log.WirteLog("wait the git.exe run, and the numbers of running git.exe is : " + gitCount);
                    }
                    // wait upload finish
                    do
                    {
                        Thread.Sleep(10000);
                        gitCount = Process.GetProcessesByName("git").Count();
                        if (gitCount == 0)
                        {
                            Log.WirteLog("finish upload :" + repositoryName);
                            break;
                        }
                        Log.WirteLog("wait upload finish, and the numbers of running git.exe is : " + gitCount);
                    } while (true);

                    hasUploadCount++;
                    Log.WirteLog(string.Format("Uploaded Count : {0}/{1}", HasUploadCount, UploadTotalCount));

                    Cmd.ShutDown("cmd");
                    Thread.Sleep(1000);
                }
                isFinish = true;
            }
            catch (Exception e)
            {
                uploadFailedCount++;
                HandleException.WirteLog(e.Message, e.StackTrace);
                StartUpUpload();
            }
        }

        /// <summary>
        /// 删除项目的"bin"和"obj"目录及其所有子目录
        /// </summary>
        /// <param name="projectDir"></param>
        private void DeleteBinAndObj(string projectDir)
        {
            string deleteDirPath = "";

            IList<string> dllPaths = new List<string>();
            FileOperation.GetFilesWithExt(projectDir, R.ExtDll, ref dllPaths);
            try
            {
                //Delete bin
                foreach (string dllPath in dllPaths)
                {
                    if (dllPath.Contains("bin") && dllPath.Contains("Debug"))
                    {
                        deleteDirPath = dllPath.Substring(0, dllPath.LastIndexOf("bin"));
                        deleteDirPath = MyPath.Combine(deleteDirPath, "bin");
                        FileOperation.DeleteDirectory(deleteDirPath);
                        Log.WirteLog(string.Format("Delete {0} directory finish ", deleteDirPath));
                        break;
                    }

                }
                //Delete obj
                foreach (string dllPath in dllPaths)
                {
                    if (dllPath.Contains("obj") && dllPath.Contains("Debug"))
                    {
                        deleteDirPath = dllPath.Substring(0, dllPath.LastIndexOf("obj"));
                        deleteDirPath = MyPath.Combine(deleteDirPath, "obj");
                        FileOperation.DeleteDirectory(deleteDirPath);
                        Log.WirteLog(string.Format("Delete {0} directory finish ", deleteDirPath));
                        break;
                    }
                }
            }
            catch (Exception e)
            {
                Log.WirteLog(string.Format("Delete Failed {0} directory  ", deleteDirPath));
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        ///  生成将要执行的bat批处理文件
        /// </summary>
        /// <param name="projectDir">文件目录</param>
        /// <returns>批处理文件所在路径</returns>
        private string GenerateBatFile(string projectDir)
        {
            string repositoryName = projectDir.Split(R.Sep()).Last();
            string args1 = MyPath.Combine(projectDir);
            string args2 = Config.GitHubOfCompany + repositoryName + ".git";
            string templateFilePath = MyPath.Combine(FileOperation.GetParentDirOfBin(), R.Settings, "upload_template.bat");
            string batFilePath = null;
            try
            {
                // read the template bat file to a string;
                string cmds = File.ReadAllText(templateFilePath, Encoding.UTF8);

                // replace args1 and args2
                cmds = cmds.Replace("args1", args1);
                cmds = cmds.Replace("args2", args2);

                // save the new string to a bat file
                batFilePath = MyPath.Combine(Config.UploadBatDir, repositoryName + ".bat");
                if (!File.Exists(batFilePath))
                {
                    FileOperation.CreateFileAndDir(batFilePath);
                }
                else
                {
                    File.Delete(batFilePath);
                }
                File.WriteAllText(batFilePath, cmds, Encoding.UTF8);
            }
            catch (Exception e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
            return batFilePath;
        }

        private async Task CreateRepository(string repositoryName)
        {
            try
            {
                var client = new GitHubClient(new ProductHeaderValue(R.ProductHeader));

                //证书 NOTE: not real credentials
                var basicAuth = new Credentials(Config.GitHubUserName, Config.GitHubPassWord);
                client.Credentials = basicAuth;
                Repository rep = await client.Repository.Create(new NewRepository(repositoryName));
            }
            catch (Exception e)
            {
                string shortMsg = e.Message;
                if (shortMsg.Contains("already"))
                    return;
                else
                    await CreateRepository(repositoryName);
                string stackMsg = e.StackTrace;
                HandleException.WirteLog(shortMsg, stackMsg);
            }
        }

        /// <summary>
        /// 删除库
        /// </summary>
        /// <param name="repositoryName">库</param>
        /// <returns></returns>
        private async Task DeleteRepository(string repositoryName)
        {
            try
            {
                var client = new GitHubClient(new ProductHeaderValue(R.ProductHeader));

                //证书 NOTE: not real credentials
                var basicAuth = new Credentials(Config.GitHubUserName, Config.GitHubPassWord);
                client.Credentials = basicAuth;
                await client.Repository.Delete(Config.GitHubUserName, repositoryName);
                Console.WriteLine("Delete " + repositoryName + " Success");
            }
            catch (Exception e)
            {
                string shortMsg = e.Message;
                if (shortMsg.Equals("Not Found"))
                {
                    Console.WriteLine("Delete " + repositoryName + " Success");
                    return;
                }
                string stackMsg = e.StackTrace;
                HandleException.WirteLog(shortMsg, stackMsg);
            }
        }

    }
}

