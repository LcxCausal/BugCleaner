﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace ThinkGeo.BugChecker
{
    public class Download
    {
        private bool isStart;
        private bool isFinish;
      
        private object sycObj = new object();

        //需要下载的总数;
        private int zipsTotalCount;

        //下载进度报告时间间隔;
        private int reportInterval = 10000;

        //下载开始的时间
        private int downloadstartTime = 0;

        public int ReportInterval
        {
            get { return reportInterval; }
            set { reportInterval = value; }
        }
      
        public int ZipsTotalCount
        {
            get { return zipsTotalCount; }
        }

        public object SycObj
        {
            get { return sycObj; }
        }

        public ConcurrentQueue<Zip> ZipQueue
        {
            get { return zipQueue; }
        }

        public HashSet<Zip> DownloadingZipSet
        {
            get { return downloadingZipSet; }
        }

        public HashSet<Zip> ZipsHasDownload
        {
            get { return zipsHasDownload; }
        }

        public int DownloadstartTime
        {
            get
            {
                return downloadstartTime;
            }

            set
            {
                downloadstartTime = value;
            }
        }

        public bool IsStart
        {
            get
            {
                lock (sycObj)
                {
                    return isStart;
                }
            }

            set
            {
                lock (sycObj)
                {
                    isStart = value;
                }
            }
        }

        public bool IsFinish
        {
            get
            {
                lock (sycObj)
                {
                    return isFinish;
                }
            }

            set
            {
                lock (sycObj)
                {
                    isFinish = value;
                }
            }
        }

        //用到的集合
        private ConcurrentQueue<Zip> zipQueue = new ConcurrentQueue<Zip>();
        private HashSet<Zip> downloadingZipSet = new HashSet<Zip>();

        //汇报进度的集合;
        private HashSet<Zip> zipsHasDownload = new HashSet<Zip>();

        public void StartupDownload()
        {
            TaskFactory taskFactory = new TaskFactory();
            Task[] tasks = new Task[Config.threadsNumber];
            try
            {
                // 读取规则
                ReadXml();
                // download
                for (int i = 0; i < Config.threadsNumber; i++)
                {
                    tasks[i] = taskFactory.StartNew(() =>
                    {
                        DownloadTask();
                    }, TaskCreationOptions.AttachedToParent);
                }
                taskFactory.ContinueWhenAll(tasks, (Task[] t) =>
                {
                    Console.WriteLine("Download finishi");
                    Log.WirteLog("Download finishi");
                    IsFinish = true;
                }, TaskContinuationOptions.AttachedToParent);

                DownloadReport();
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                StartupDownload();
            }
        }

        /// <summary>
        /// 下载结果报告
        /// </summary>
        private void DownloadReport()
        {
            while (true)
            {
                if (isFinish)
                {
                    break;
                }
                lock (sycObj)
                {
                    Log.WirteLog(string.Format("Numbers of downloading zip: {0}", downloadingZipSet.Count()));
                    Log.WirteLog(string.Format("Numbers of downloaded zip: {0}", zipsHasDownload.Count()));
                }
                Thread.Sleep(ReportInterval);
            }
            lock (sycObj)
            {
                Log.WirteLog(string.Format("Numbers of downloading zip: {0}", downloadingZipSet.Count()));
                Log.WirteLog(string.Format("Numbers of downloaded zip: {0}", zipsHasDownload.Count()));
            }
        }

        /// <summary>
        /// 读取储存下载信息的xml文件
        /// 1. 去除各分类中的交叉引用链接;
        /// </summary>
        /// <param name="fullPath">xml文件路径</param>
        private void ReadXml()
        {
            try
            {
                string fullPath = Config.crawlerResultFilePath;
                HashSet<string> urlWillDownload = new HashSet<string>();

                //取每个分类下的url;
                string xPath = XmlOperations.Combine(R.CrawlerResultRootNODE);
                foreach (string category in XmlOperations.GetChildsNameList(fullPath, xPath))
                {
                    xPath = XmlOperations.Combine(R.CrawlerResultRootNODE, category);
                    foreach (string url in XmlOperations.GetOneNodeChildsContent(fullPath, xPath))
                    {
                        //交叉引用只放一个到下载队列;
                        if (!urlWillDownload.Contains(url))
                        {
                            ZipQueue.Enqueue(new Zip(category, url));
                            urlWillDownload.Add(url);
                        }
                    }

                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }

            //待爬zip总数;
            zipsTotalCount = ZipQueue.Count;
            Log.WirteLog("zipsTotalCount:" + ZipsTotalCount);
            Log.WirteLog(string.Format("Read {0} finish", Config.crawlerResultFileName));
        }

        /// <summary>
        /// 单个下载线程的任务
        /// </summary>
        private void DownloadTask()
        {
            try
            {
                Zip zip = null;
                while (true)
                {
                    //在外部设置下载线程停止；
                    if (isFinish)
                    {
                        break;
                    }
                    lock (SycObj)
                    {
                        //弹出成功;
                        if (ZipQueue.TryDequeue(out zip))
                        {
                            Add(DownloadingZipSet, zip);
                        }
                        //队列空弹出失败,url为null;
                        else
                        {
                            if (DownloadingZipSet.Any())
                                continue;
                            else
                                return;
                        }
                    }

                    string dir;
                    string url;
                    string fileName;

                    dir = Config.downloadZipsDir;
                    url = zip.Url;

                    fileName = GetFileNameFromUrl(url);

                    Log.WirteLog(string.Format("Start download {0}", fileName));

                    //保存到该文件;
                    string saveZipFilePath = MyPath.Combine(dir, fileName);
                    string downloadResult = DownloadRemoteFile(url, saveZipFilePath);
                    Remove(DownloadingZipSet, zip);

                    switch (downloadResult)
                    {
                        case "0"://下载失败
                            Add(ZipQueue, zip);
                            Log.WirteLog("download failed(queue again): \n" + zip.Url.ToString());

                            break;
                        case "1"://下载成功: 新增或更新的项目
                            Log.WirteLog("download success(new or update): \n" + zip.Url.ToString());
                            Add(ZipsHasDownload, zip);
                            break;
                        case "2"://已存在
                            Log.WirteLog("download success(exisit): \n" + zip.Url.ToString());
                            Add(ZipsHasDownload, zip);
                            break;
                    }

                    lock (SycObj)
                    {
                        Console.WriteLine("Download process: {0}/{1}", ZipsHasDownload.Count(), ZipsTotalCount);
                        Log.WirteLog(string.Format("Download process: {0}/{1}", ZipsHasDownload.Count(), ZipsTotalCount));
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        ///  下载url对应文件，并保存在本地
        /// </summary>
        /// <param name="url">wiki官网下载地址</param>
        /// <param name="fullPath">保存到本地的文件全路径</param>
        /// <param name="md5Length">需要校验的文件片段长度</param>
        /// <returns>0:下载失败; 1:下载新项目成功 2:已存在</returns>
        private string DownloadRemoteFile(string url, string fullPath)
        {
            string result = "1";
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            try
            {
                //判断已下载项目是否更新
                if (File.Exists(fullPath))
                {
                    //通过新旧项目文件的长度来判断项目是否更新 
                    if (FileOperation.CompareByLength(url, fullPath))
                    {
                        return "2";
                    }
                    //文件更新,则删除原来的文件
                    else
                    {
                        File.Delete(fullPath);
                    }
                }
                //文件为新增或有改动,则需下载;
                //设置接收信息的缓冲器
                var bytes = new byte[4096];
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    Log.WirteLog(string.Format("Server response StatusCode ：{0}", response.StatusCode));

                    //向服务器请求，获得服务器的回应数据流
                    using (var stream = response.GetResponseStream())
                    {
                        using (var outStream = new MemoryStream())
                        {
                            int count;

                            //读取时注意实际接收数据大小
                            while ((count = stream.Read(bytes, 0, bytes.Length)) != 0)
                            {
                                //将接收数据写入
                                outStream.Write(bytes, 0, count);
                            }

                            //把MemoryStream的内容直接输出到一个二进制文件当中,不使用for循环
                            FileOperation.CreateFileAndDir(fullPath);
                            using (FileStream fs = new FileStream(fullPath, FileMode.OpenOrCreate))
                            {
                                byte[] buff = outStream.ToArray();
                                fs.Write(buff, 0, buff.Length);
                            }
                        }
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
                result = "0";
            }
            return result;
        }

        /// <summary>
        /// 从url中提取保存的文件名: xxx.zip
        /// </summary>
        /// <param name="url"></param>
        /// <returns>文件名</returns>
        private string GetFileNameFromUrl(string url)
        {
            string fileName = null;
            fileName = url.Substring(url.LastIndexOf("/") + 1);
            return fileName;
        }

        /// <summary>
        /// 增加集合元素
        /// </summary>
        /// <param name="collection">集合</param>
        /// <param name="zip">新增元素</param>
        private void Add(IEnumerable<Zip> collection, Zip zip)
        {
            Type type = collection.GetType();
            object obj1 = Convert.ChangeType(collection, collection.GetType());
            if (obj1 is HashSet<Zip>)
            {
                lock (SycObj)
                {
                    HashSet<Zip> hs = (HashSet<Zip>)collection;
                    hs.Add(zip);
                }
            }
            if (obj1 is ConcurrentQueue<Zip>)
            {
                lock (SycObj)
                {
                    ConcurrentQueue<Zip> queue = (ConcurrentQueue<Zip>)collection;
                    queue.Enqueue(zip);
                }
            }
        }

        /// <summary>
        /// 删除集合元素
        /// </summary>
        /// <param name="collection">集合</param>
        /// <param name="zip">元素</param>
        private void Remove(IEnumerable<Zip> collection, Zip zip)
        {

            Type type = collection.GetType();
            object obj1 = Convert.ChangeType(collection, collection.GetType());
            if (obj1 is HashSet<Zip>)
            {
                lock (SycObj)
                {
                    HashSet<Zip> hs = (HashSet<Zip>)collection;
                    hs.Remove(zip);
                }
            }
            if (obj1 is ConcurrentQueue<Zip>)
            {
                lock (SycObj)
                {
                    ConcurrentQueue<Zip> queue = (ConcurrentQueue<Zip>)collection;
                    queue.TryDequeue(out zip);
                }
            }
        }
    }
}
