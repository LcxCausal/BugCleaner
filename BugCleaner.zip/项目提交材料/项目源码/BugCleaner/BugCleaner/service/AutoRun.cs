﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace ThinkGeo.BugChecker
{
    public class AutoRun
    {
        private bool isFinish;

        public bool IsFinish
        {
            get { return isFinish; }
        }

        /// <summary>
        /// 单线程运行各个项目
        /// </summary>
        public void StartupAutoRun()
        {
            string projectName;
            try
            {
                foreach (string projectDir in Directory.GetDirectories(Config.compileSuccessDirPath))
                {
                    projectName = projectDir.Split(R.Sep()).Last();
                    IList<string> slns = new List<string>();
                    FileOperation.GetFilesWithExt(projectDir, R.ExtSln, ref slns);
                    if (slns.Any())
                    {
                        string sln = "";

                        //取得sln文件
                        foreach (string slnItem in slns)
                        {
                            //Backup文件夹下sln的不执行
                            if (!slnItem.Contains("Backup"))
                            {
                                sln = slnItem;
                                break;
                            }
                        }

                        //# run sln
                        RunSln(sln);

                        //# 模拟点击VS的"Start"按钮,启动调试 
                        SimulateVSDebug();

                        //# screenshot
                        string slnName = Path.GetFileNameWithoutExtension(sln);
                        string imgSavePath = Path.Combine(Config.autoRunRootDir, R.ScreenShot, projectName, slnName + R.JPG);
                        ScreenShot.ScreenShotFullScreen(imgSavePath);
                        Thread.Sleep(1000);

                        // 关闭 VS,默认浏览器
                        Cmd.ShutDown(R.VsDevenvExeName);
                        Cmd.ShutDown(Config.DefaultVsDebugBroserName);
                    }
                }
                isFinish = true;
                Tools.WirteRedToConsole("Auto Run Finish!");
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        /// <summary>
        /// 使用VS打开sln,等待VS启动完成
        /// </summary>
        /// <param name="sln">sln路径</param>
        private void RunSln(string sln)
        {
            string command;
            command = string.Format("\"{0}\" \"{1}\"", Config.vsExe, sln);
            Cmd.RunCmdNoOut(command, Config.cmdExe);

            //等待vs启动完成;
            while (true)
            {
                if (Cmd.IsExeRun(R.VsDevenvExeName))
                {
                    Thread.Sleep(Config.WaitVsStartUsedTimes);
                    break;
                }
            }
        }

        /// <summary>
        /// 模拟VS调试项目
        /// 通过模拟人工操作鼠标键盘,实现点击"Start"或"开始"按钮,进而启动调试
        /// </summary>
        private void SimulateVSDebug()
        {
            //鼠标定位到"Start"按钮
            SimulateKeyMouse.SetCursorPos(Config.Position_X, Config.Position_Y);
            Thread.Sleep(1000);
            SimulateKeyMouse.LeftMouseDoubleClick();

            //# 留出项目运行的时间;
            Thread.Sleep(Config.WaitProjectRunUsedTimes);
        }
    }
}
