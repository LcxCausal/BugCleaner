﻿using HtmlAgilityPack;
using System.Collections.Generic;
using System.Linq;

namespace ThinkGeo.BugChecker
{
    //解析特点:比如 All_samples
    public class SpecifiedHrefsHtmlParser : HtmlParser
    {
        public SpecifiedHrefsHtmlParser(CrawlerRule rule, string prefix)
        {
            Prefix = prefix;
            Rule = rule;
        }

        public override IList<Url> GetHrefsWithFilter(Url url)
        {
            HashSet<Url> hashset = new HashSet<Url>();
            string regex = Rule.regex;
            HtmlNodeCollection hrefs = base.GetAllHrefs(url);
            if (hrefs == null)
            {
                return null;
            }
            string subHref;
            string category;
            int depth;
            Url subUrl;
            foreach (HtmlNode htmlnode in hrefs)
            {
                subHref = Prefix + htmlnode.Attributes["href"].Value;
                category = url.Category;
                depth = url.Depth;
                subUrl = new Url(subHref, category, depth + 1);
                if (subHref.Contains(regex))
                {
                    if (!hashset.Contains(subUrl))
                    {
                        hashset.Add(subUrl);
                    }
                }
            }
            return hashset.ToList();
        }
    }
}
