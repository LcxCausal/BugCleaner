﻿using HtmlAgilityPack;
using System.Collections.Generic;
using System.Linq;

namespace ThinkGeo.BugChecker
{
    //解析特点: 获取所有子链接，不做任何筛选; 比如 *.zip格式的子链接
    public class AllHrefsHtmlParser : HtmlParser
    {
        public AllHrefsHtmlParser(CrawlerRule rule, string prefix)
        {
            Prefix = prefix;
            Rule = rule;
        }

        public override IList<Url> GetHrefsWithFilter(Url url)
        {
            HashSet<Url> hashset = new HashSet<Url>();
            HtmlNodeCollection hrefs = GetAllHrefs(url);
            if (hrefs == null)
            {
                return null;
            }
            string subHref;
            string category;
            int depth;
            Url subUrl;
            foreach (HtmlNode htmlnode in hrefs)
            {
                subHref = Prefix + htmlnode.Attributes["href"].Value;
                category = url.Category;
                depth = url.Depth;
                subUrl = new Url(subHref, category, depth + 1);

                if (!hashset.Contains(subUrl))
                {
                    hashset.Add(subUrl);
                }
            }
            return hashset.ToList();
        }
    }
}
