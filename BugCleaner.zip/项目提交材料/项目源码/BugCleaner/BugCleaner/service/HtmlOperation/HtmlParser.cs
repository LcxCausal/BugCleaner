﻿using HtmlAgilityPack;
using System.Collections.Generic;

namespace ThinkGeo.BugChecker
{
    //抽象解析器类
    public abstract class HtmlParser
    {
        //# rule和prefix 唯一确定一个解析器;
        // 网址前缀(网站域名)
        private string prefix;

        // 爬取规则
        private CrawlerRule rule;

        public string Prefix
        {
            get { return prefix; }
            set { prefix = value; }
        }

        public CrawlerRule Rule
        {
            get { return rule; }
            set { rule = value; }
        }


        /// <summary>
        /// 根据传入的url,自动寻找规则进行爬虫;
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public abstract IList<Url> GetHrefsWithFilter(Url url);//解析失败时，抛异常通知调用者爬取失败

        protected HtmlNodeCollection GetAllHrefs(Url url)
        {
            HashSet<Url> hashset = new HashSet<Url>();
            string xpath = Rule.xpath;
            HtmlWeb hw = new HtmlAgilityPack.HtmlWeb();
            HtmlDocument doc = hw.Load(url.AbsoluteUrl);
            return doc.DocumentNode.SelectNodes(xpath);
        }
    }
}
