﻿using HtmlAgilityPack;
using System.Collections.Generic;
using System.Linq;

namespace ThinkGeo.BugChecker
{
    //解析特点; 获取所有子链，并且给每个子链接打上分类标签; 一般是作为首页解析器
    public class HomePageHtmlParser : HtmlParser
    {
        public HomePageHtmlParser(CrawlerRule rule, string prefix)
        {
            Prefix = prefix;
            Rule = rule;
        }

        public override IList<Url> GetHrefsWithFilter(Url url)
        {
            HashSet<Url> hashset = new HashSet<Url>();
            HtmlNodeCollection hrefs = base.GetAllHrefs(url);
            if (hrefs == null)
                return null;
            string sub_href;
            string category;
            int depth;
            foreach (HtmlNode htmlnode in hrefs)
            {
                sub_href = Prefix + htmlnode.Attributes["href"].Value;
                category = htmlnode.InnerText;
                depth = url.Depth;
                Url sub_url = new Url(sub_href, category, depth + 1);
                if (!hashset.Contains(sub_url))
                    hashset.Add(sub_url);
            }
            return hashset.ToList();
        }
    }
}
