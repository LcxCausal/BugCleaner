﻿using System.Collections.Generic;

namespace ThinkGeo.BugChecker
{
    /// <summary>
    /// 根据url对应的不同规则，返回不同的解析器;
    /// 传入url返回过滤后的Url集合;
    /// </summary>
    public class HtmlParserContext
    {
        private HtmlParser htmlParserSuper;

        public HtmlParser HtmlParserSuper
        {
            get { return htmlParserSuper; }
            set { htmlParserSuper = value; }
        }

        public HtmlParser CreateHtmlParser(Url url, CrawlerRule rule)
        {
            switch (url.Depth)
            {
                //xpath区域所有子链,给子链设置类别标签;"*.edition"+innerText(Android)
                case 1:
                    HtmlParserSuper = new HomePageHtmlParser(rule, Config.prefix);
                    break;

                //regex包含"all_samples"
                case 2:
                    HtmlParserSuper = new SpecifiedHrefsHtmlParser(rule, Config.prefix);
                    break;

                //regex = innerText;"C# Download"
                case 3:
                    HtmlParserSuper = new InnerTextHtmlParser(rule, Config.prefix);
                    break;

                //xpath区域所有子链;"*.zip"
                //页面所有链接;
                case 4:
                    HtmlParserSuper = new AllHrefsHtmlParser(rule, Config.prefix);
                    break;
            }
            return HtmlParserSuper;
        }

        /// <summary>
        /// 返回页面中的下级线索:List<Url>
        /// </summary>
        /// <param name="url"></param>
        /// <returns>下级线索集合</returns>
        public IList<Url> GetSubHrefsWithFilter(Url url)
        {
            return HtmlParserSuper.GetHrefsWithFilter(url);
        }
    }

}
