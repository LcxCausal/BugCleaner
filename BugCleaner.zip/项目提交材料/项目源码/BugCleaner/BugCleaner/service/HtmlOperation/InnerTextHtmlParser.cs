﻿using HtmlAgilityPack;
using System.Collections.Generic;
using System.Linq;

namespace ThinkGeo.BugChecker
{
    //解析特点;　获取指定InnertText的子链接; 比如 C# Download
    public class InnerTextHtmlParser : HtmlParser
    {
        public InnerTextHtmlParser(CrawlerRule rule, string prefix)
        {
            Prefix = prefix;
            Rule = rule;
        }

        public override IList<Url> GetHrefsWithFilter(Url url)
        {

            HashSet<Url> hashset = new HashSet<Url>();
            string innerText;
            string regex = Rule.regex;
            HtmlNodeCollection hrefs = GetAllHrefs(url);
            if (hrefs == null)
            {
                return null;
            }
            string subHref;
            string category;
            int depth;
            foreach (HtmlNode htmlnode in hrefs)
            {
                subHref = Prefix + htmlnode.Attributes["href"].Value;
                category = url.Category;
                depth = url.Depth;
                Url sub_url = new Url(subHref, category, depth + 1);
                innerText = htmlnode.InnerText;
                if (innerText.Equals(regex))
                {
                    if (!hashset.Contains(sub_url))
                    {
                        hashset.Add(sub_url);
                    }
                }
            }
            return hashset.ToList();
        }
    }
}
