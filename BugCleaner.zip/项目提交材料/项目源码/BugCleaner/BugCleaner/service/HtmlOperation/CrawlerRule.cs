﻿namespace ThinkGeo.BugChecker
{
    public struct CrawlerRule
    {
        //xpath路径 (定位到页面的目标区域)
        public string xpath;

        //regular expression (定位到目标区域的目标字符串)
        public string regex;

        public CrawlerRule(string xpath, string regex)
        {
            this.xpath = xpath;
            this.regex = regex;
        }
    }
}
