﻿using System;

namespace ThinkGeo.BugChecker
{
    //analysisHtmlAndExtractUrls使用多个参数 而不使用结构体了;
    //多线程 传递参数需要把数据包裹起来，还是要用到结构体;
    public class Url : IComparable<Url>
    {
        private string absoluteUrl;
        private string category;

        //获取了depth,也就获取了规则;
        private int depth;

        private static int equalsCount = 0;
        private static int hashCodeCount = 0;
        private static int compareToCount = 0;

        public Url(string absoluteUrl, string category, int depth)
        {
            this.absoluteUrl = absoluteUrl;
            this.category = category;
            this.depth = depth;
        }

        public string AbsoluteUrl
        {
            get { return absoluteUrl; }
        }

        public string Category
        {
            get { return category; }
        }

        public int Depth
        {
            get { return depth; }
        }

        public override int GetHashCode()
        {
            hashCodeCount++;
            int hash = 13;
            return AbsoluteUrl.GetHashCode() * hash + Category.GetHashCode() + Depth.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            equalsCount++;

            if (obj == null)
                return false;

            if (GetType() != obj.GetType())
                return false;

            Url url = (Url)obj;

            if (AbsoluteUrl.Equals(url.AbsoluteUrl))
                return true;

            return false;
        }

        public override string ToString()
        {
            return "depth:" + Depth + "  \n" + "category:" + Category + "  \n" + "absoluteUrl" + AbsoluteUrl + "\n";
        }

        public int CompareTo(Url url)
        {
            compareToCount++;

            if (Depth == url.Depth)
            {
                if (Category.Equals(url.Category))
                {
                    return 0;
                }
                else
                {
                    return Category.CompareTo(url.Category);
                }
            }
            else
            {
                return Depth > url.Depth ? 1 : -1;
            }
        }
    }
}
