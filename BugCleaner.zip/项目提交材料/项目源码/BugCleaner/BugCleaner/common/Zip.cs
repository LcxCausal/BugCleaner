﻿namespace ThinkGeo.BugChecker
{
    public class Zip
    {
        private string category;
        private string url;

        public Zip(string category, string url)
        {
            this.category = category;
            this.url = url;
        }

        public string Category
        {
            get { return category; }
        }

        public string Url
        {
            get { return url; }
        }

        public override string ToString()
        {
            return "category:" + Category + "  \n" + "zipfileName:" + Url.Substring(Url.LastIndexOf("/")) + "\n";
        }

        public override bool Equals(object obj)
        {
            //判断与之比较的类型是否为null。这样不会造成递归的情况
            if (obj == null)
            {
                return false;
            }

            if (GetType() != obj.GetType())
            {
                return false;
            }

            Zip zip = (Zip)obj;

            if (Category.Equals(zip.Category))
            {
                if (Url.Equals(zip.Url))
                {
                    return true;
                }
            }
            return false;
        }

        public override int GetHashCode()
        {
            int hash = 13;
            return Category.GetHashCode() * hash + Url.GetHashCode() * hash;
        }
    }
}
