﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ThinkGeo.BugChecker
{
    /// <summary>
    /// 1. 存放程序的固有配置(目录,文件保存名)
    /// 2. 读取所有从文件中读取的配置
    /// </summary>
    public static class Config
    {
        static Config()
        {
            InitCategoryMap();
            ReadCrawlerRules();
            InitReplaceDicOfDll();
            InitThreadsNumber();
        }

        #region 需要配置的部分

        //所有磁盘操作限制在该目录下
        public static string rootDir = MyPath.Combine("C:", "BugChecker", GetDateString());

        //github账号
        public static string GitHubUserName = "sicnuthinkgeo";
        public static string GitHubPassWord = "thinkgeo1";

        //vs安装目录下devenv.exe的绝对路径
        //如: C:\Program Files(x86)\Microsoft Visual Studio 14.0\Common7\IDE\devenv.exe
        public static string vsExe = "C:\\Program Files (x86)\\Microsoft Visual Studio 14.0\\Common7\\IDE\\devenv.exe";

        //cmd.exe
        public static string cmdExe = "C:\\Windows\\System32\\cmd.exe";

        //vs的MSBuild编译器路径
        public static string msbuildExe = "C:\\Program Files (x86)\\MSBuild\\14.0\\Bin\\amd64\\MSBuild.exe";

        // thinkgeo软件安装目录
        public static string installDir = MyPath.Combine("C:\\Program Files (x86)\\ThinkGeo\\");

        // 系统盘下的"Program Files (x86)"文件夹路径
        public static string Microsoft_Dir = MyPath.Combine("C:\\Program Files (x86)");

        /*自动运行阶段的参数*/

        //一个时间值,单位毫秒; 该值表示从点击vs2015软件图标,到界面基本加载完毕的用时(“Start”按钮 或 "开始"按钮可用,表示界面加载完毕)
        public static int WaitVsStartUsedTimes = 16000;

        //一个时间值,单位毫秒; 该值表示需要自动运行的项目,从被启动调试到基本运行出界面的用时;
        public static int WaitProjectRunUsedTimes = 16000;

        //"Start"按钮在屏幕的位置
        public static int Position_X = 500;
        public static int Position_Y = 70;

        //VS调试时默认的浏览器在任务管理其中的的进程名,不包括.exe"
        public static string DefaultVsDebugBroserName = "chrome"; //chrome浏览器

        #endregion

        public static string resourceDirName = "resource";

        //最优线程数
        public static int threadsNumber;

        /// <summary>
        /// 设置爬取分类名和保存分类名的对应关系
        /// </summary>
        private static void InitCategoryMap()
        {
            categoryMap.Add("WPF_Desktop_Edition", "#Wpf");
            categoryMap.Add("World_Map_Kit_SDK", "#WMKS");
            categoryMap.Add("WMS_Server_Edition", "#WMS");
            categoryMap.Add("Winforms_Desktop_Edition", "#Winforms");
            categoryMap.Add("Windows_Phone_Edition", "#WPE");
            categoryMap.Add("WebAPI_Edition", "#WebAPI");
            categoryMap.Add("Web_Edition", "#Web");
            categoryMap.Add("Silverlight_Edition", "#Silverlight");
            categoryMap.Add("Services_Edition", "#Services");
            categoryMap.Add("Routing_Extension", "#Routing");
            categoryMap.Add("MVC_Edition", "#MVC");
            categoryMap.Add("iOS_Edition", "#iOS");
            categoryMap.Add("Geocoder", "#Geo");
        }

        /// <summary>
        /// 设置最优线程数;
        /// </summary>
        private static void InitThreadsNumber()
        {
            threadsNumber = Environment.ProcessorCount * 2 - 1;
        }

        /// <summary>
        /// 获取当前时间,如2016-04-24(22h)
        /// </summary>
        /// <returns></returns>
        private static string GetDateAndHour()
        {
            string date = DateTime.Now.ToString("yyyy-MM-dd");
            string time = DateTime.Now.ToShortTimeString().ToString();
            return date + "(" + time.Substring(0, time.IndexOf(':')) + "h)";
        }

        /// <summary>
        /// 返回今天的时间: yyyy-MM-dd 
        /// </summary>
        /// <returns></returns>
        private static string GetDateString()
        {
            string date = DateTime.Now.ToString("yyyy-MM-dd");
            return date;
        }

        //爬取结果文件名
        public static string crawlerResultFileName = "ThinkGeoUrlsOfAllZips.xml";

        //爬虫规则文件名
        public static string crawlerRulesFileName = "crawlerRules.xml";

        //爬取结果保存目录
        public static string crawlerResultSaveDir = MyPath.Combine(rootDir, "CrawlerResult");

        //爬虫结果文件全路径
        public static string crawlerResultFilePath = MyPath.Combine(Config.crawlerResultSaveDir, Config.crawlerResultFileName);

        //入口网址
        public static string entryUrl;

        //相对路径到绝对路径的前缀替换;
        public static string prefix;

        public static ConcurrentDictionary<int, CrawlerRule> rulesDictonary = new ConcurrentDictionary<int, CrawlerRule>();

        /// <summary>
        /// 读取爬虫规则文件
        /// </summary>
        private static void ReadCrawlerRules()
        {
            try
            {
                string crawlerRulesFilePath = MyPath.Combine(Tools.GetParentDirOfBin(), resourceDirName, crawlerRulesFileName);

                //#取入口网址;
                // XMLNODE_RULELIST + "//" + XMLNODE_RULENODE + "[" + 1 + "]";
                string xPath = "//" + R.BaseUrl;
                entryUrl = XmlOperations.GetOneNodeContent(crawlerRulesFilePath, xPath);

                //#取网站前缀
                xPath = "//" + R.Prefix;
                prefix = XmlOperations.GetOneNodeContent(crawlerRulesFilePath, xPath);

                //取规则;
                xPath = "//" + R.RuleList;

                //规则个数;
                int n = XmlOperations.StatisticsAllChildsOfOneNode(crawlerRulesFilePath, xPath);

                string xp = string.Empty;
                string regex = string.Empty;
                int depth;
                CrawlerRule rule;

                //取所有规则,放入规则字典中
                for (int i = 1; i < n + 1; i++)
                {
                    xPath = "//" + R.RuleList + "//" + R.RuleNode + "[" + i + "]";
                    xp = XmlOperations.GetAttribute(crawlerRulesFilePath, xPath, R.XPath);
                    regex = XmlOperations.GetAttribute(crawlerRulesFilePath, xPath, R.RegularExpression);
                    depth = Convert.ToInt32(XmlOperations.GetAttribute(crawlerRulesFilePath, xPath, R.Depth));
                    rule = new CrawlerRule(xp, regex);
                    rulesDictonary.TryAdd(depth, rule);
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        //保存下载的zip的目录名
        public static string downloadZipsDir = MyPath.Combine(rootDir, "Download");
        public static int MD5PartsLen = 1024;

        //解压到该目录
        public static string UnZipDirPath = MyPath.Combine(rootDir, "Unzip");

        //编译成功项目存放目录
        public static string compileSuccessDirPath = MyPath.Combine(rootDir, "UPload");

        //编译失败项目存放目录
        public static string compileFailedDirPath = MyPath.Combine(rootDir, "F");

        //记录缺失的dll
        public static string lackDllFile = "LackOfDlls.txt";

        /// <summary>
        /// 字典数据说明
        /// 1.  key : 表示dll的名字; 如 desktop.dll
        /// 2. value : 表示dll文件的绝对路径; 如
        /// value1:
        /// D:\Program Files (x86)\ThinkGeo\Map Suite 9.0\Map Suite Android\Current Version\Managed Assemblies\desktop.dll;
        /// </summary>
        public static IDictionary<string, string> replaceDllDic = new Dictionary<string, string>();

        /// <summary>
        ///  为replaceDllDic填充数据
        /// </summary>
        /// <returns></returns>
        private static void InitReplaceDicOfDll()
        {
            try
            {
                //# 获取软件安装目录 非强名的dll
                IList<string> thinkgeoDlls = new List<string>();
                FileOperation.GetFilesWithExt(installDir, R.ExtDll, ref thinkgeoDlls);
                foreach (string dllPath in thinkgeoDlls)
                {
                    string fileName = dllPath.Split(R.Sep()).Last().ToLower();
                    if (!replaceDllDic.ContainsKey(fileName))
                        replaceDllDic.Add(fileName, dllPath);
                }

                //# 获取C:\\Program Files (x86)\\*Microsoft*\\* 下的所有dll
                foreach (string subDir in Directory.GetDirectories(Microsoft_Dir))
                {
                    string DirName = subDir.Split(R.Sep()).Last();
                    if (!DirName.Contains("Microsoft"))
                        continue;
                    IList<string> Microsoft_Dlls = new List<string>();
                    FileOperation.GetFilesWithExt(subDir, R.ExtDll, ref Microsoft_Dlls);

                    foreach (string dllPath in Microsoft_Dlls)
                    {
                        string fileName = dllPath.Split(R.Sep()).Last().ToLower();
                        if (!replaceDllDic.ContainsKey(fileName))
                            replaceDllDic.Add(fileName, dllPath);
                    }
                }
            }
            catch (InvalidOperationException e)
            {
                HandleException.WirteLog(e.Message, e.StackTrace);
            }
        }

        //分类映射Map
        public static IDictionary<string, string> categoryMap = new Dictionary<string, string>();

        public static string autoRunRootDir = rootDir;

        public static string UploadDirPath = MyPath.Combine(rootDir, "Upload");
        public static string UploadBatDir = MyPath.Combine(rootDir, "UploadBatFiles");

        //github地址
        public static string GitHubOfCompany = "https://github.com/" + GitHubUserName + "/";
    }
}
